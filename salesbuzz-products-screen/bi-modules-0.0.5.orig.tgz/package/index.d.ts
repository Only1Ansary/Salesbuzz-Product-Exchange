import { MessageService } from '@progress/kendo-angular-l10n';
import * as i0 from '@angular/core';
import { Type, AfterViewInit, OnDestroy, ElementRef, EventEmitter, PipeTransform, OnInit, ChangeDetectorRef, OnChanges, SimpleChanges, TemplateRef, ViewContainerRef, ComponentRef, QueryList, Renderer2 } from '@angular/core';
import * as i80 from '@angular/material/snack-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as i88 from 'bi-interfaces';
import { ILogger, ICreateDialog, IScreen, IRecentScreen, ICustomScreenLayout, IColumnConfig, IUIProfileService, IColumns, INav, ILayoutSaver, IGrid, INavBtn, RecordSourceEnum, IControls, NavInfo, IErrorMessages, IExportSettings, IDataSource, IChangeset, IPopup, DataTypes, ISearchItem, IMenuItem, ILookup, Subscription as Subscription$1, IDropDown, ITree, IBiAnchorPopup, IGridSteps, IGallery, IPhotoUploader, ICardFilter, ICards, ExtendedMap, ICardNav, ICardSorter, IDialog } from 'bi-interfaces';
import * as i82 from '@ngx-translate/core';
import { TranslateService } from '@ngx-translate/core';
import * as i85 from '@angular/material/dialog';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import * as rxjs from 'rxjs';
import { Subject, Subscription, BehaviorSubject } from 'rxjs';
import * as i71 from '@angular/forms';
import { FormControl, FormBuilder, FormGroup, AbstractControl, ValidatorFn } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as i70 from '@progress/kendo-angular-grid';
import { CellClickEvent, CellCloseEvent, GridComponent, CreateFormGroupArgs, GridItem, PageChangeEvent as PageChangeEvent$1 } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor, State, FilterDescriptor, SortDescriptor } from '@progress/kendo-data-query';
import * as i72 from '@progress/kendo-angular-pager';
import { PageChangeEvent } from '@progress/kendo-angular-pager';
import * as i83 from '@progress/kendo-angular-intl';
import { IntlService } from '@progress/kendo-angular-intl';
import * as i100 from '@angular/common';
import { LocationStrategy, DatePipe, DecimalPipe } from '@angular/common';
import * as i74 from '@progress/kendo-angular-layout';
import { GridLayoutItemComponent, GridLayoutComponent, DrawerComponent, DrawerSelectEvent } from '@progress/kendo-angular-layout';
import { BreakpointObserver } from '@angular/cdk/layout';
import { SVGIcon } from '@progress/kendo-svg-icons';
import { Clipboard } from '@angular/cdk/clipboard';
import * as i87 from '@progress/kendo-angular-treeview';
import { FilterState } from '@progress/kendo-angular-treeview';
import * as moment from 'moment';
import Collapse from 'bootstrap/js/dist/collapse';
import { DomSanitizer } from '@angular/platform-browser';
import * as i89 from '@progress/kendo-angular-upload';
import { FileRestrictions, SelectEvent, UploadComponent, UploadProgressEvent } from '@progress/kendo-angular-upload';
import * as i92 from '@progress/kendo-angular-listview';
import { ListViewComponent } from '@progress/kendo-angular-listview';
import * as i105 from '@angular/material/bottom-sheet';
import { MatBottomSheet, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import * as i99 from '@angular/cdk/drag-drop';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { MatTabGroup } from '@angular/material/tabs';
import * as i67 from '@full-fledged/alerts';
import * as i68 from '@progress/kendo-angular-icons';
import * as i69 from '@progress/kendo-angular-dateinputs';
import * as i73 from '@progress/kendo-angular-filter';
import * as i75 from '@progress/kendo-angular-dropdowns';
import * as i76 from '@progress/kendo-angular-dialog';
import * as i77 from '@progress/kendo-angular-inputs';
import * as i78 from '@progress/kendo-angular-buttons';
import * as i79 from '@progress/kendo-angular-popup';
import * as i81 from '@angular/material/tooltip';
import * as i84 from '@angular/material/datepicker';
import * as i86 from '@angular/material/core';
import * as i90 from 'ngx-mask';
import * as i91 from '@progress/kendo-angular-label';
import * as i93 from '@angular/material/radio';
import * as i94 from '@angular/material/input';
import * as i95 from '@angular/material/select';
import * as i96 from '@angular/material/form-field';
import * as i97 from '@angular/material/icon';
import * as i98 from '@angular/material/menu';
import * as i101 from '@angular/material-moment-adapter';
import * as i102 from '@ngxmc/datetime-picker';
import * as i103 from '@angular/material/chips';
import * as i104 from '@angular/material/badge';

declare class BIModulesService {
    private messages;
    localId: string;
    constructor(messages: MessageService);
    getDir(): boolean;
    setDir(): void;
    getLocal(): "ar-EG" | "fr-FR" | "fa-IR" | "en-US";
    static ɵfac: i0.ɵɵFactoryDeclaration<BIModulesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BIModulesService>;
}

declare class LoggerService implements ILogger {
    private _snackBar;
    Type: number;
    Content: string;
    TypesClass: {
        0: string;
        1: string;
        2: string;
        3: string;
    };
    constructor(_snackBar: MatSnackBar);
    Show(): void;
    alertShow(content: string, type: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}

declare class CreateDialog implements ICreateDialog {
    dialog: MatDialog;
    DialogReturnSubject: Subject<any>;
    DialogRef: any;
    constructor();
    ShowDialog(component: Type<any>, data: any, modalTitle?: any, firstButtonName?: any, secondButtonName?: any, hasCancelBtn?: boolean, hasOkBtn?: boolean): void;
    CloseDialog(): void;
}

declare class ColViewService {
    ColNumber: Subject<number>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ColViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ColViewService>;
}

declare class UserUIProfile {
    FavoriteScreens: IScreen[];
    RecentScreens: IRecentScreen[];
    BS_CustomScreenLayout: ICustomScreenLayout | null;
    BS_GridColumnConfigs: IColumnConfig[];
    constructor();
}

declare class UiProfileService implements IUIProfileService {
    UserUIProfile: UserUIProfile;
    IsUserUIProfileFilled: boolean;
    UserUIProfileFilledSubject: Subject<void>;
    UserUIProfileFilled$: rxjs.Observable<void>;
    isCurrentScreenFavoriteDelegate?: () => boolean;
    private recentPageSubject;
    recentPage$: rxjs.Observable<IScreen>;
    private saveColumnLayoutSubject;
    saveColumnLayout$: rxjs.Observable<any>;
    private saveColumnsConfigSubject;
    saveColumnsConfig$: rxjs.Observable<any>;
    private favoriteScreenChangedSubject;
    favoriteScreenChanged$: rxjs.Observable<{
        isFavorite: boolean;
        pageUrl: string;
    }>;
    constructor();
    emitSaveColumnLayout(layoutColumns: number | null): void;
    emitSaveColumnsConfig(gridDomId: string, columns: IColumns[]): void;
    emitrecentPage(page: IScreen): void;
    emitfavoriteScreenChanged(_isFavorite: boolean, _pageUrl?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiProfileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UiProfileService>;
}

declare class BiNavComponent implements INav, ILayoutSaver, AfterViewInit, OnDestroy {
    loggerService: LoggerService;
    biService: BIModulesService;
    elementRef: ElementRef;
    translateService: TranslateService;
    _dialog: any;
    ColViewService: ColViewService;
    private router;
    private uiProfileService;
    private NavInfoService;
    [x: string]: any;
    BIGrid: IGrid;
    DomID: string;
    PageTitle: string;
    RowTitle: string;
    CanInsert: boolean;
    CanUpdate: boolean;
    CanDelete: boolean;
    CanSave: boolean;
    CanViewAttachments: boolean;
    CanAddAttachments: boolean;
    CanDeleteAttachments: boolean;
    CanPrint: boolean | undefined;
    HistoryData: {
        Table: string;
        KeyID: string;
    };
    navButtons: INavBtn;
    deleteConfirmMsg: boolean;
    StorageLocation: 0 | 1 | null;
    OnPrint: EventEmitter<any>;
    ActionClicked: EventEmitter<any>;
    opened: boolean;
    addBtn: ElementRef | any;
    saveBtn: ElementRef | any;
    cancelBtn: ElementRef | any;
    deleteBtn: ElementRef | any;
    attachBtn: ElementRef | any;
    infoBtn: ElementRef | any;
    HistoryDataBtn: ElementRef | any;
    RecordSource: any;
    RecordSourceEnum: typeof RecordSourceEnum;
    CreatedBy: string;
    CreatedOn: Date;
    ModifiedBy: string;
    ModifiedOn: Date;
    BUID: string;
    BUDesc: string;
    private subscription;
    CurrentSelectedLayout: number | null;
    AttachmentDialog: CreateDialog;
    ViewList: {
        text: any;
        code: number;
    }[];
    ViewControl: FormControl;
    ViewControlI: IControls;
    scrollContainerRef: ElementRef;
    scrollLeftArrowRef: ElementRef;
    scrollRightArrowRef: ElementRef;
    scrollPosition: number;
    showLeftArrow: boolean;
    showRightArrow: boolean;
    private resizeObserver;
    constructor(loggerService: LoggerService, biService: BIModulesService, elementRef: ElementRef, translateService: TranslateService, _dialog: any, ColViewService: ColViewService, router: ActivatedRoute, uiProfileService: UiProfileService, NavInfoService: NavInfo);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    updateArrows(): void;
    scrollLeft(): void;
    scrollRight(): void;
    checkBordersStyle(element: any): boolean;
    /**
     * add new row to the grid
     * @return void
     */
    AddRow(): void;
    /**
     * delete row from the grid
     * @return void
     */
    DeleteRow(): void;
    /**
     * save edits in any cell
     * @return void
     */
    Cancel(): void;
    /**
     * save edits in any cell
     * @return void
     */
    Save(): void;
    /**
  * attachment in any cell
  * @return void
  */
    Attachment(): void;
    /**
  * wotkflow in any cell
  * @return void
  */
    WorkFlow(): void;
    /**
    * info in any cell
    * @return void
    */
    Info(): void;
    /**
      * close info popup
      * @return void
    */
    Close(): void;
    Print(): void;
    HistoryDataClick(): void;
    GetErpawarePermission(): boolean;
    OnViewselectionChanges(number: number): void;
    SaveLayoutForScreenClicked(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiNavComponent, "BI-Nav", never, { "BIGrid": { "alias": "BIGrid"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; "PageTitle": { "alias": "PageTitle"; "required": false; }; "RowTitle": { "alias": "RowTitle"; "required": false; }; "CanInsert": { "alias": "CanInsert"; "required": false; }; "CanUpdate": { "alias": "CanUpdate"; "required": false; }; "CanDelete": { "alias": "CanDelete"; "required": false; }; "CanSave": { "alias": "CanSave"; "required": false; }; "CanViewAttachments": { "alias": "CanViewAttachments"; "required": false; }; "CanAddAttachments": { "alias": "CanAddAttachments"; "required": false; }; "CanDeleteAttachments": { "alias": "CanDeleteAttachments"; "required": false; }; "CanPrint": { "alias": "CanPrint"; "required": false; }; "HistoryData": { "alias": "HistoryData"; "required": false; }; "navButtons": { "alias": "navButtons"; "required": false; }; "deleteConfirmMsg": { "alias": "deleteConfirmMsg"; "required": false; }; "StorageLocation": { "alias": "StorageLocation"; "required": false; }; }, { "OnPrint": "OnPrint"; "ActionClicked": "ActionClicked"; }, never, ["[biNavDesc]", "*"], false, never>;
}

declare class GetValuePipe implements PipeTransform {
    transform(value: any, ...args: string[]): any;
    get(obj: any, ...selectors: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<GetValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GetValuePipe, "getValue", false>;
}

declare class ErrorDetailsService implements IErrorMessages {
    Title: string;
    Details: string;
    Link: string;
    Parameter: string;
    Id: number;
    Type: number;
    showErrorMsg: boolean;
    ErrorMessagesQueue: IErrorMessages[];
    constructor();
    PushErrorMessages(error: IErrorMessages): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorDetailsService>;
}

declare enum StatusAction$1 {
    ADD = "Add",
    UPDATE = "Update",
    NOP = "NOP",
    Delete = "Delete"
}
declare enum BeforeAction {
    NoSaveImp = "NoSaveImp",
    NoDeleteImp = "NoDeleteImp"
}
declare class BIGridComponent implements OnInit, OnDestroy, IGrid, IExportSettings {
    _dialog: any;
    localeId: string;
    intlService: IntlService;
    formBuilder: FormBuilder;
    loggerService: LoggerService;
    biService: BIModulesService;
    messages: MessageService;
    getValuePipe: GetValuePipe;
    translateService: TranslateService;
    private cd;
    errorDetailsService: ErrorDetailsService;
    router: Router;
    private uiProfileService;
    DataService: IDataSource;
    changeSet: IChangeset;
    Columns: IColumns[];
    GridName: string;
    refGrid: string;
    DomID: string;
    HasPaging: boolean;
    HasSelectAll: boolean;
    HasFullHeight: boolean;
    HasExport: boolean;
    ExportFileName: string;
    colors: any;
    rowCallback: any;
    CellClick: EventEmitter<CellClickEvent>;
    CellClose: EventEmitter<CellCloseEvent>;
    RowChange: EventEmitter<any>;
    RowChangeMasterGridChangeDetails: EventEmitter<any>;
    OnLoadData: EventEmitter<any>;
    BeforeAddRow: EventEmitter<any>;
    OnAddRow: EventEmitter<any>;
    AfterAddRow: EventEmitter<any>;
    OnCloseRow: EventEmitter<any>;
    AfterSave: EventEmitter<any>;
    AfterAdd: EventEmitter<any>;
    AfterCancel: EventEmitter<any>;
    SortChanges: EventEmitter<any>;
    ChangeAllCheckBoxes: EventEmitter<any>;
    beforeCheckAll: EventEmitter<any>;
    BeforeDeleteRow: EventEmitter<any>;
    CheckBoxChange: EventEmitter<any>;
    Mygrid: GridComponent;
    customizeColumnsDialogTemplate: any;
    openPopUpDialog: IPopup;
    customizeColumnsDialog: CreateDialog;
    isCustomizeColumnsVisible: boolean;
    statusAction: StatusAction$1;
    AllowSave: Subject<boolean>;
    AllowDelete: Subject<boolean>;
    AllowAdd: Subject<boolean>;
    form: any;
    DefaultValue: any;
    CurrentSelectRow: FormGroup;
    rowCol: IColumns;
    Status: IColumns;
    formGroups: FormGroup[];
    GridData: any;
    mySelection: number[];
    rowIndex: any;
    dataItem: any;
    dataItemReset: any;
    data: any;
    newForm: any;
    prevRow: any;
    totalDataLength: number;
    RowID: string;
    RowIdentifier: string;
    ChangeSet_Status: string;
    GridDataSubscription: Subscription;
    RowSubscription: Subscription;
    StopDeleteSubscription: Subscription;
    StopAddSubscription: Subscription;
    StopSaveSubscription: Subscription;
    DeleteSubscription: Subscription;
    AddSubscription: Subscription;
    EditSaveSubscription: Subscription;
    filter: any;
    height: number;
    GridID: string;
    RowCount: number;
    checkboxColumnIndexLastChanged: number;
    private userProfileFilledSub;
    private datePipe;
    locationStrategy: LocationStrategy;
    IsHeader: boolean;
    GetNewRowID(): string;
    getFormGroup(RowID: string | any): FormGroup;
    constructor(_dialog: any, localeId: string, intlService: IntlService, formBuilder: FormBuilder, loggerService: LoggerService, biService: BIModulesService, messages: MessageService, getValuePipe: GetValuePipe, translateService: TranslateService, cd: ChangeDetectorRef, errorDetailsService: ErrorDetailsService, router: Router, uiProfileService: UiProfileService);
    ngOnInit(): void;
    private ApplyUserColumnsConfigs;
    ReAssignColumns(): void;
    PushChangesArr(): void;
    read(): void;
    handleFormGroup(): void;
    CompareBetweenTwoDate(res: any, dataItem: any): boolean;
    changeCheckBox(event: any, Name: string, dataItem: any, rowIndex: any, columnIndex: any): void;
    changeCheckAll(event: any, Name: string): void;
    bindingData(event: any, name: string): void;
    createFormGroup(args?: CreateFormGroupArgs | any): FormGroup;
    GetGridData(): void;
    ClearGrid(): void;
    OverviewDataBindingSubscribtion(RowID: string): void;
    InitReactiveFormData(): void;
    BeforeActionSave(): BeforeAction;
    BeforeActionDelete(): BeforeAction;
    AfterActionSave(): void;
    cellCloseHandler(args: CellCloseEvent): void;
    assignValues(target: any, source: any): void;
    trackByItem(index: number, item: GridItem): any;
    CheckPendingChange(): boolean;
    IsDirty(formGroups: FormGroup[]): boolean;
    IsDirtyAndCheckValid(formGroups: FormGroup[]): boolean;
    AddRow(): void;
    DeleteRow(): Promise<void>;
    insertDataItemInRow(args: any): void;
    cellClickHandler(args: CellClickEvent): void;
    set resetRowIndex(rowIndex: number);
    filterByDropList(e: any, filterService: any, Name: string): void;
    private GridDataBeforeFiltering;
    onValueChange(e: any): void;
    ResetRowUpdateStatus(): void;
    Cancel(): void;
    alertShow(content: string, type: number): void;
    ValidateDirtyBeforeSave(formgroups: FormGroup[]): void;
    PrepareBodyReq(data: any): any;
    getTypeFilter(Key: string): DataTypes | undefined;
    HandleFilterApiRequest(response: any): string;
    HandleFormateTypeKeysReq(Key: string, Value: any): any;
    HandleParamsApiRequest(Value: any): string;
    DoAdd(): void;
    GetUpdatedProperties(myForm: FormGroup<any> | undefined): any;
    DoUpdate(): void;
    SaveWithoutConfirmation(): Promise<void>;
    getDisplayName(fieldName: string, columns: IColumns[]): string | undefined;
    Save(): Promise<void>;
    preventInvalidInput(event: KeyboardEvent): void;
    CompearObjectByKey(keys: any[], obj1: any, obj2: any): boolean;
    PrepareInsertedITems(CreatedItemArray: Array<FormGroup<any>>, excludeDataFromReq: Array<string>): Array<any>;
    PrepareUpdatedITems(updatedtemArray: Array<FormGroup<any>>, excludeDataFromReq: Array<string>): Array<any>;
    PrepareDeletedITems(DeletedArray: Array<FormGroup<any>>): Array<any>;
    saveAll(): Promise<void>;
    closeRow(rowIndex?: number): void;
    onPageChange(e: PageChangeEvent): void;
    changePage(e: PageChangeEvent): void;
    GetDropDownTxtValueByCode(code: any, dropDownTemplet: any): any;
    handleDate(date: Date | any): any;
    setDefaultDate(form: any): void;
    updateCurrentSelectedRow(data: any): void;
    ngOnDestroy(): void;
    PleventCloseRow: boolean;
    setPreventCloseRow: BehaviorSubject<boolean>;
    setPreventCloseRowSubscription: Subscription;
    Kendofilter: CompositeFilterDescriptor;
    filterChange(filter: CompositeFilterDescriptor): void;
    GetDropDownStatusColorByCode(code: any, dropDownTemplet: any): any;
    RefreshCurrentRow(AfterRefreshFunc: Function): Subscription;
    opened: string;
    DialogText: string;
    close(status: string): void;
    open(event: any, res: any, data: any): void;
    openDialog(event: any, res: any, data: any): void;
    getvalidateLookupValueCheckExistence(flagVal: boolean | undefined): boolean;
    EnableDisable_columns(colmnNames: string[], IsEditable: boolean): void;
    GetCurrentSelectRow_ChangeSetStatus(): string;
    SetValue(ColumnName: string, Value: any, MarkAsDirty?: boolean): void;
    GetRowValue(): any;
    GetValueOf(Name: string): any;
    goToPage(pPage?: string, id?: string): void;
    ConvertBoolean2Number(): void;
    setFilter(fieldName: string, value: string, type: DataTypes): void;
    setLookupFilter(fieldName: string, value: string, type: DataTypes): void;
    private normalizeFieldForOData;
    ExportToExcel(): void;
    ResetFilters(): void;
    ShowDialog(domid: string): void;
    filterServices: {
        [field: string]: any;
    };
    filterControls: {
        [field: string]: FormControl;
    };
    filterSubscriptions: {
        [key: string]: Subscription;
    };
    registerFilterService(field: string, service: any): void;
    getFilterControl(field: string): FormControl;
    applyLookupFilter(value: any, field: string): void;
    ReadAfterFilteration(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGridComponent, "BI-Grid", never, { "DataService": { "alias": "DataService"; "required": false; }; "changeSet": { "alias": "changeSet"; "required": false; }; "Columns": { "alias": "Columns"; "required": false; }; "GridName": { "alias": "GridName"; "required": false; }; "refGrid": { "alias": "refGrid"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; "HasPaging": { "alias": "HasPaging"; "required": false; }; "HasSelectAll": { "alias": "HasSelectAll"; "required": false; }; "HasFullHeight": { "alias": "HasFullHeight"; "required": false; }; "HasExport": { "alias": "HasExport"; "required": false; }; "ExportFileName": { "alias": "ExportFileName"; "required": false; }; "colors": { "alias": "colors"; "required": false; }; "rowCallback": { "alias": "rowCallback"; "required": false; }; "height": { "alias": "height"; "required": false; }; }, { "CellClick": "CellClick"; "CellClose": "CellClose"; "RowChange": "RowChange"; "RowChangeMasterGridChangeDetails": "RowChangeMasterGridChangeDetails"; "OnLoadData": "OnLoadData"; "BeforeAddRow": "BeforeAddRow"; "OnAddRow": "OnAddRow"; "AfterAddRow": "AfterAddRow"; "OnCloseRow": "OnCloseRow"; "AfterSave": "AfterSave"; "AfterAdd": "AfterAdd"; "AfterCancel": "AfterCancel"; "SortChanges": "SortChanges"; "ChangeAllCheckBoxes": "ChangeAllCheckBoxes"; "beforeCheckAll": "beforeCheckAll"; "BeforeDeleteRow": "BeforeDeleteRow"; "CheckBoxChange": "CheckBoxChange"; }, never, never, false, never>;
}

declare class BIChildGridComponent extends BIGridComponent implements IGrid {
    _createDialog: CreateDialog;
    selectAll: boolean;
    ForceDiasbleRowIdsCheckBox: number[];
    currentLang: string;
    constructor(formBuilder: FormBuilder, loggerService: LoggerService, biService: BIModulesService, messages: MessageService, getValuePipe: GetValuePipe, cd: ChangeDetectorRef, translateService: TranslateService, errorDetailsService: ErrorDetailsService, localeId: any, intlService: IntlService, router: Router, uiProfileService: UiProfileService, _createDialog: CreateDialog);
    read(): void;
    AddRow(): void;
    DeleteRow(): Promise<void>;
    changeCheckBox(event: any, Name: string, dataItem: any, rowIndex: any): void;
    cellClickHandler(args: CellClickEvent): Promise<void>;
    Save(): Promise<void>;
    Cancel(): void;
    ConvertBoolean2Number(): void;
    IsDisabledCellTemplate(RowID: string, controlName: string): boolean;
    onPageChange(e: PageChangeEvent$1): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIChildGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIChildGridComponent, "BI-ChildGrid", never, {}, {}, never, never, false, never>;
}

declare class BIGridLayoutItemComponent extends GridLayoutItemComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGridLayoutItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGridLayoutItemComponent, "BI-grid-layout-item", never, {}, {}, never, ["*"], false, never>;
}

declare class BIGridLayoutComponent extends GridLayoutComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGridLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGridLayoutComponent, "BI-grid-layout", never, {}, {}, never, ["*"], false, never>;
}

declare class BISearchComponent implements OnInit {
    translateService: TranslateService;
    biService: BIModulesService;
    searchChanges: EventEmitter<any>;
    searchDataList: ISearchItem[];
    searchReportManagerList: ISearchItem[];
    searchFormControl: FormControl;
    private filteredData;
    constructor(translateService: TranslateService, biService: BIModulesService);
    ngOnInit(): void;
    resetControl(): void;
    private handleFilter;
    static ɵfac: i0.ɵɵFactoryDeclaration<BISearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BISearchComponent, "bi-search", never, { "searchDataList": { "alias": "searchDataList"; "required": false; }; "searchReportManagerList": { "alias": "searchReportManagerList"; "required": false; }; }, { "searchChanges": "searchChanges"; }, never, never, false, never>;
}

declare class BISideBarComponent implements OnChanges {
    private router;
    private breakpointObserver;
    biService: BIModulesService;
    private uiProfileService;
    selected: string;
    items: Array<IMenuItem>;
    excludedFromSearchIndexes: number[];
    collapsed: boolean;
    isMobileOrTablet: boolean;
    closed: boolean;
    collapseSideContent: boolean;
    searchValue: string;
    searchDataList: any[];
    searchResults: any[];
    selectedMenuItem: string[];
    showSearchInSideContent: boolean;
    menuSVG: SVGIcon;
    closeSVG: SVGIcon;
    BiSearch: BISearchComponent;
    drawer: DrawerComponent;
    isRightToLeft: any;
    isRight: boolean;
    onClick(e: HTMLElement): void;
    constructor(router: Router, breakpointObserver: BreakpointObserver, biService: BIModulesService, uiProfileService: UiProfileService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onSelect(ev: DrawerSelectEvent | any): void;
    changeBackGround(): void;
    navigateToScreen(path: string): void;
    closeMenu(): void;
    backToNav(): void;
    CheckToggleDrawer(): void;
    private selectMenuItem;
    private resetSelectedMenuItem;
    getRouteToNavigate(event: {
        path: string;
        text: string;
        pathInBreadCrumb: string[];
    }): void;
    getSearchChanges(event: {
        value: string;
        searchResults: any[];
    }): void;
    private flattenMenuItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<BISideBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BISideBarComponent, "Bi-Sidebar", never, { "items": { "alias": "items"; "required": false; }; "excludedFromSearchIndexes": { "alias": "excludedFromSearchIndexes"; "required": false; }; "isRightToLeft": { "alias": "isRightToLeft"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIPopupMenuComponent implements OnInit, OnDestroy {
    private elRef;
    y: string;
    x: string;
    visibility: string;
    width: string;
    constructor(elRef: ElementRef);
    visible: boolean;
    ngOnInit(): void;
    open(e: MouseEvent): void;
    close(): void;
    onDocumentClick(): void;
    onDocumentRClick(event: _Event): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIPopupMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIPopupMenuComponent, "bi-popup-menu", never, { "width": { "alias": "width"; "required": false; }; }, {}, never, [".menu"], false, never>;
}

declare class BILookupComponent implements OnInit, ILookup, OnDestroy, OnChanges {
    dialog: MatDialog;
    translateService: TranslateService;
    ReturnedValueEmitter: EventEmitter<any>;
    OnFocus: EventEmitter<any>;
    OnOpen: EventEmitter<any>;
    BeforeLoad: EventEmitter<any>;
    AfterLoad: EventEmitter<any>;
    OnEnterGrid: EventEmitter<any>;
    OnClose: EventEmitter<any>;
    OnHover: EventEmitter<any>;
    OnChange: EventEmitter<any>;
    ErrorStateEmitter: EventEmitter<any>;
    multiRowsEmitter: EventEmitter<any>;
    OnOpenSecondLkp: EventEmitter<any>;
    hasSelection: boolean | undefined;
    DomID: string | undefined;
    Description: string | undefined;
    DataSource: IDataSource;
    Key: string | undefined;
    classNameSelector: string;
    Title: string;
    rtlDescription: string;
    IsDisabled: boolean;
    BindingProperty: FormControl;
    Lookuptemplet: any;
    lookupValue: any;
    DisplayCancel: boolean;
    DataType: string;
    hasSecondLkp: boolean;
    setPreventCloseRow: BehaviorSubject<boolean>;
    validateCheckExistence?: boolean;
    style?: string;
    route?: string;
    hasPendingChanges?: boolean;
    Isvalid: boolean;
    SelectedRow: any;
    GoToDefinitionURl: string;
    opened: boolean;
    ModalID: string;
    DescriptionText: string;
    GridDataLookupSubscription: Subscription$1;
    gridData: any[] | null;
    data$: any;
    ErrorMsg: string;
    state: State;
    lookupvale: any;
    multiSelectedRows: any;
    hasMultiSelectedRows: any;
    dialogRef: MatDialogRef<any>;
    mobile: boolean;
    EnteredValue: string;
    localDataBackup: any;
    currentFilter: any;
    menu: BIPopupMenuComponent;
    input: ElementRef;
    router: Router;
    clipboard: Clipboard;
    loggerService: LoggerService;
    locationStrategy: LocationStrategy;
    constructor(dialog: MatDialog, translateService: TranslateService);
    clickout(): void;
    ngOnChanges(changes: SimpleChanges): void;
    OnInputFocus(): void;
    CloseModal(): void;
    OpenModal(): void;
    getLookupData(filter?: any): void;
    ngOnInit(): void;
    CheckExistence(): void;
    cellClickHandler(args: CellClickEvent): void;
    OnInputHover(): void;
    SetIsDisable(IsDisabled: boolean): void;
    FilterChange(e: any): void;
    SetError(ErrMsg: string): void;
    ClearError(): void;
    Ok(): void;
    Cancel(): void;
    dblClickEvent(): void;
    OnTextChange(event: any): Promise<void>;
    showContextMenu(e: any): void;
    changeTextValue(value: any): void;
    openDialog(): void;
    openSecondLkp(): void;
    ngOnDestroy(): void;
    openMenu(e: MouseEvent): void;
    GotoDefinition(): void;
    alertShow(content: string, type: number): void;
    copy(): void;
    cut(): void;
    paste(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BILookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BILookupComponent, "app-bi-lookup", never, { "hasSelection": { "alias": "hasSelection"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; "Description": { "alias": "Description"; "required": false; }; "DataSource": { "alias": "DataSource"; "required": false; }; "Key": { "alias": "Key"; "required": false; }; "classNameSelector": { "alias": "classNameSelector"; "required": false; }; "Title": { "alias": "Title"; "required": false; }; "rtlDescription": { "alias": "rtlDescription"; "required": false; }; "IsDisabled": { "alias": "IsDisabled"; "required": false; }; "BindingProperty": { "alias": "BindingProperty"; "required": false; }; "Lookuptemplet": { "alias": "Lookuptemplet"; "required": false; }; "lookupValue": { "alias": "lookupValue"; "required": false; }; "DisplayCancel": { "alias": "DisplayCancel"; "required": false; }; "DataType": { "alias": "DataType"; "required": false; }; "hasSecondLkp": { "alias": "hasSecondLkp"; "required": false; }; "setPreventCloseRow": { "alias": "setPreventCloseRow"; "required": false; }; "validateCheckExistence": { "alias": "validateCheckExistence"; "required": false; }; "style": { "alias": "style"; "required": false; }; "route": { "alias": "route"; "required": false; }; "hasPendingChanges": { "alias": "hasPendingChanges"; "required": false; }; }, { "ReturnedValueEmitter": "ReturnedValueEmitter"; "OnFocus": "OnFocus"; "OnOpen": "OnOpen"; "BeforeLoad": "BeforeLoad"; "AfterLoad": "AfterLoad"; "OnEnterGrid": "OnEnterGrid"; "OnClose": "OnClose"; "OnHover": "OnHover"; "OnChange": "OnChange"; "ErrorStateEmitter": "ErrorStateEmitter"; "multiRowsEmitter": "multiRowsEmitter"; "OnOpenSecondLkp": "OnOpenSecondLkp"; }, never, never, false, never>;
}

declare class BiFloatingLookupComponent extends BILookupComponent {
    Control: IControls;
    FormGroup: FormGroup;
    DomID: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiFloatingLookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiFloatingLookupComponent, "bi-floating-lookup", never, { "Control": { "alias": "Control"; "required": false; }; "FormGroup": { "alias": "FormGroup"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BiDropDownComponent implements IDropDown {
    bindingDrop: any;
    IsDisabled: boolean;
    OnValueChange: EventEmitter<any>;
    OnselectionChange: EventEmitter<any>;
    OnFocus: EventEmitter<any>;
    OnOpen: EventEmitter<any>;
    FilterData: any[] | undefined;
    orig: any[];
    SelectedRow: any;
    DropDownList: any[] | undefined;
    TextField: any;
    ValueField: any;
    BindingProperty: FormControl;
    DefaultItem: any;
    Name: any;
    HasStatuesIcon: boolean;
    IsFilterable: boolean;
    style?: string;
    DomId?: string;
    title: string;
    styleType: 'small' | 'medium' | 'large' | 'none';
    valueChange(event: any): void;
    selectionChange(event: any): void;
    ngOnChanges(changes: SimpleChanges): void;
    focus(): void;
    open(): void;
    handleFilter(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiDropDownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiDropDownComponent, "bi-dropDown", never, { "IsDisabled": { "alias": "IsDisabled"; "required": false; }; "SelectedRow": { "alias": "SelectedRow"; "required": false; }; "DropDownList": { "alias": "DropDownList"; "required": false; }; "TextField": { "alias": "TextField"; "required": false; }; "ValueField": { "alias": "ValueField"; "required": false; }; "BindingProperty": { "alias": "BindingProperty"; "required": false; }; "DefaultItem": { "alias": "DefaultItem"; "required": false; }; "Name": { "alias": "Name"; "required": false; }; "HasStatuesIcon": { "alias": "HasStatuesIcon"; "required": false; }; "IsFilterable": { "alias": "IsFilterable"; "required": false; }; "style": { "alias": "style"; "required": false; }; "DomId": { "alias": "DomId"; "required": false; }; "title": { "alias": "title"; "required": false; }; "styleType": { "alias": "styleType"; "required": false; }; }, { "OnValueChange": "OnValueChange"; "OnselectionChange": "OnselectionChange"; "OnFocus": "OnFocus"; "OnOpen": "OnOpen"; }, never, never, false, never>;
}

declare class BiFloatingDropDownComponent extends BiDropDownComponent {
    Label?: string;
    Control: IControls;
    DomId?: any;
    selectionChange(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiFloatingDropDownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiFloatingDropDownComponent, "bi-floating-drop-down", never, { "Label": { "alias": "Label"; "required": false; }; "Control": { "alias": "Control"; "required": false; }; "DomId": { "alias": "DomId"; "required": false; }; }, {}, never, never, false, never>;
}

declare class SideBarContentComponent implements OnChanges {
    private uiProfileService;
    selectedItem: string;
    items: any;
    collapsed: boolean;
    isRight: boolean;
    selectedMenuItem: string[];
    ChildReports: any;
    backToNav: EventEmitter<any>;
    navigateToScreen: EventEmitter<string>;
    expandedPanels: {
        [key: string]: number;
    };
    childExpandedPanels: {
        [key: string]: number;
    };
    activeButton: any;
    constructor(uiProfileService: UiProfileService);
    ngOnChanges(changes: SimpleChanges): void;
    private applySelection;
    private applyExpansation;
    private resetExpansation;
    returnToNav(): void;
    navigate(path: string): void;
    setActiveButton(buttonText: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SideBarContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SideBarContentComponent, "SideBar-content", never, { "selectedItem": { "alias": "selectedItem"; "required": false; }; "items": { "alias": "items"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "isRight": { "alias": "isRight"; "required": false; }; "selectedMenuItem": { "alias": "selectedMenuItem"; "required": false; }; "ChildReports": { "alias": "ChildReports"; "required": false; }; }, { "backToNav": "backToNav"; "navigateToScreen": "navigateToScreen"; }, never, never, false, never>;
}

declare class BiMultiSelectComponent extends BiDropDownComponent {
    Label?: string;
    Control: IControls;
    DomId?: any;
    matSelectArray: FormControl;
    private bindingValueChangeSub?;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    selectionChange(event: any): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiMultiSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiMultiSelectComponent, "bi-multiSelect", never, { "Label": { "alias": "Label"; "required": false; }; "Control": { "alias": "Control"; "required": false; }; "DomId": { "alias": "DomId"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIChildGridGenericDataTypeComponent extends BIChildGridComponent {
    /**
      * A dictionary that maps column names to their respective dependent column that contains their data types.
      *
      * This object enables defining specific data types for each row,
      * where each key represents a column name, and each value specifies
      * the column that contains the datatype expected for that column.
      *
      * Example usage:
      * ```
      * this.columnDataTypes["UpperValue"] = "ValueDataType";
      * ```
      * where UpperValue is the column and ValueDataType is the column that contains its datatype
      *
      * @type {{ [key: string]: string }}
      */
    columnDataTypes: {
        [key: string]: string;
    };
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIChildGridGenericDataTypeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIChildGridGenericDataTypeComponent, "bichild-grid-generic", never, { "columnDataTypes": { "alias": "columnDataTypes"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIModalComponent implements OnDestroy {
    biService: BIModulesService;
    dialogRef: MatDialogRef<BIModalComponent>;
    Parentdata: any;
    private messages;
    opened: boolean;
    selectedRows: Set<string>;
    totalDataLength: number;
    SelectAllValue: boolean;
    dataSubscriber: Subscription | null;
    constructor(biService: BIModulesService, dialogRef: MatDialogRef<BIModalComponent>, Parentdata: any, messages: MessageService);
    onNoClick(): void;
    CloseDialog(): void;
    OnDblClick(): void;
    OK(): void;
    onCheckboxChanged(dataItem: any): void;
    Kendofilter: CompositeFilterDescriptor;
    onPageChange(e: any): void;
    private restoreSelectionsForCurrentPage;
    FilterChange(state: any): void;
    openedError: boolean;
    DialogText: string;
    close(status: string): void;
    open(event: any, res: any, data: any): void;
    ChangeSelectAll(event: any): void;
    GetDropDownTxtValueByCode(code: any, dropDownTemplet: any): any;
    filterByDropList(e: any, filterService: any, Name: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIModalComponent, "lib-bi-modal", never, {}, {}, never, never, false, never>;
}

declare class GetGenericValuePipe implements PipeTransform {
    private datepipe;
    constructor(datepipe: DatePipe);
    transform(value: any, valueDataType: number, ...args: string[]): any;
    get(obj: any, valueDataType: number, ...selectors: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<GetGenericValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GetGenericValuePipe, "getGenericValue", false>;
}

declare class GetChildGenericValuePipe implements PipeTransform {
    private datepipe;
    constructor(datepipe: DatePipe);
    transform(value: any, attributeType: number, ...args: string[]): any;
    get(obj: any, attributeType: number, ...selectors: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<GetChildGenericValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GetChildGenericValuePipe, "getChildGenericValue", false>;
}

/**
 * A pure pipe used to extract the filter values from the provided filter descriptors.
 */
declare class filterValuesPipe implements PipeTransform {
    transform(filter: CompositeFilterDescriptor): unknown[];
    static ɵfac: i0.ɵɵFactoryDeclaration<filterValuesPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<filterValuesPipe, "filterValues", false>;
}

declare class BIDatePickerComponent {
    dialogRef: MatDialogRef<BIDatePickerComponent>;
    private datePipe;
    RecivedData: any;
    selectedDate: any;
    constructor(dialogRef: MatDialogRef<BIDatePickerComponent>, datePipe: DatePipe, RecivedData: any);
    onCancelClick(): void;
    onDateChange(value: Date): void;
    OK(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIDatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIDatePickerComponent, "lib-bi-date-picker", never, {}, {}, never, never, false, never>;
}

declare class BIPopupComponent {
    biService: BIModulesService;
    private messages;
    dialog: MatDialog;
    Title: string;
    DisplayCancel: boolean;
    DisplayOk: boolean;
    Width: string;
    OkButtonTitle: string;
    OnOpen: EventEmitter<any>;
    OnClose: EventEmitter<any>;
    OnOk: EventEmitter<any>;
    AllowSave: Subject<boolean>;
    StopSaveSubscription: Subscription;
    dialogContentTemplate: TemplateRef<any>;
    dialogRef: MatDialogRef<any> | undefined;
    constructor(biService: BIModulesService, messages: MessageService, dialog: MatDialog);
    ngOnInit(): void;
    CloseDialog(): void;
    OK(): Promise<void>;
    openDialog(): void;
    BeforeActionSave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIPopupComponent, "BI-Popup", never, { "Title": { "alias": "Title"; "required": false; }; "DisplayCancel": { "alias": "DisplayCancel"; "required": false; }; "DisplayOk": { "alias": "DisplayOk"; "required": false; }; "Width": { "alias": "Width"; "required": false; }; "OkButtonTitle": { "alias": "OkButtonTitle"; "required": false; }; }, { "OnOpen": "OnOpen"; "OnClose": "OnClose"; "OnOk": "OnOk"; }, never, ["*"], false, never>;
}

declare class ErrorMessageComponent {
    errorDetailsService: ErrorDetailsService;
    closeErrorMessages: boolean;
    currentError: IErrorMessages | undefined;
    constructor(errorDetailsService: ErrorDetailsService);
    closeAll(): void;
    close(id: number): void;
    details(id: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorMessageComponent, "lib-error-message", never, {}, {}, never, never, false, never>;
}

declare class SideBarErrorDetailsComponent implements OnInit {
    errorDetailsService: ErrorDetailsService;
    error: IErrorMessages | undefined;
    closed: boolean;
    constructor(errorDetailsService: ErrorDetailsService);
    ngOnInit(): void;
    ToggleErrors(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SideBarErrorDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SideBarErrorDetailsComponent, "lib-side-bar-error-details", never, { "error": { "alias": "error"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DialogDirective {
    viewContainerRef: ViewContainerRef;
    constructor(viewContainerRef: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DialogDirective, "[dialogHost]", never, {}, {}, never, never, false, never>;
}

interface DialogData {
    compo: Type<any>;
    dataToRenderedComponent: any;
    title: string;
    instance: CreateDialog;
    firstButtonName: string;
    secondButtonName: string;
    hasOkBtn: boolean;
    hasCancelBtn: boolean;
}
declare class BiDialog implements OnInit {
    dialogRef: MatDialogRef<BiDialog>;
    RecivedData: DialogData;
    private translateService;
    dialoghost: DialogDirective;
    componentRef: ComponentRef<any>;
    lang: string | null;
    constructor(dialogRef: MatDialogRef<BiDialog>, RecivedData: DialogData, translateService: TranslateService);
    ngOnInit(): void;
    loadComponent(): void;
    Canel(onclose?: boolean): void;
    Ok(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiDialog, "bi-dialog", never, {}, {}, never, never, false, never>;
}

declare class NegativeValueTransformPipe implements PipeTransform {
    transform(value: number | string | null): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<NegativeValueTransformPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<NegativeValueTransformPipe, "negativeValueTransform", false>;
}

declare class BiMasterGridDetailsComponent extends BIChildGridComponent implements IGrid, AfterViewInit {
    _createDialg: CreateDialog;
    map: Map<any, any>;
    DomIDDetails: any;
    dataItems: any;
    DataServiceLines: any[];
    ColumnsLines: IColumns[];
    changeSetLines: any;
    navButtonsLinesGroup: INavBtn;
    DisabledLinesGridChild: boolean;
    Key: string;
    DataTypeKey1: string;
    DataTypeKey2: string;
    colorsLines: any;
    ManualParams: boolean;
    AfterAddRowLinesGroup: EventEmitter<any>;
    OnLoadDataDetailsGroup: EventEmitter<any>;
    OnRowChangeDataDetails: EventEmitter<any>;
    BGridDetailsChildren: QueryList<IGrid>;
    formLines: any;
    BGridDetailsChildrenGroup: any[];
    expandedDetailKeys: number[];
    constructor(formBuilder: FormBuilder, loggerService: LoggerService, biService: BIModulesService, messages: MessageService, getValuePipe: GetValuePipe, cd: ChangeDetectorRef, translateService: TranslateService, errorDetailsService: ErrorDetailsService, localeId: any, intlService: IntlService, router: Router, uiProfileService: UiProfileService, _createDialg: CreateDialog);
    Getvalue(DataITem: any): any;
    ngAfterViewInit(): void;
    insertDataItemInRow(args: any): void;
    OnLoadDataDetails(dataItem: any, rowIndex: any): Promise<void>;
    RowChangeDataDetails(dataItem: any, rowIndex: any): Promise<void>;
    AfterAddRowLine(dataItem: any, rowIndex: any): Promise<void>;
    BGridDetailsChildren_BeforeAddRow(dataItem: any): void;
    filterInRefrenceChildren(dataItem: any, rowIndex: number): any;
    EnableDisableGrid(IsEditable: boolean, dataItem: any): void;
    expandGrid(): void;
    expandDetailsBy: (dataItem: any) => number;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiMasterGridDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiMasterGridDetailsComponent, "lib-bi-master-grid-details", never, { "map": { "alias": "map"; "required": false; }; "DataServiceLines": { "alias": "DataServiceLines"; "required": false; }; "ColumnsLines": { "alias": "ColumnsLines"; "required": false; }; "changeSetLines": { "alias": "changeSetLines"; "required": false; }; "navButtonsLinesGroup": { "alias": "navButtonsLinesGroup"; "required": false; }; "DisabledLinesGridChild": { "alias": "DisabledLinesGridChild"; "required": false; }; "Key": { "alias": "Key"; "required": false; }; "DataTypeKey1": { "alias": "DataTypeKey1"; "required": false; }; "DataTypeKey2": { "alias": "DataTypeKey2"; "required": false; }; "colorsLines": { "alias": "colorsLines"; "required": false; }; "ManualParams": { "alias": "ManualParams"; "required": false; }; }, { "AfterAddRowLinesGroup": "AfterAddRowLinesGroup"; "OnLoadDataDetailsGroup": "OnLoadDataDetailsGroup"; "OnRowChangeDataDetails": "OnRowChangeDataDetails"; }, never, never, false, never>;
}

declare class BiMasterGridDetailsChildrenComponent extends BIChildGridComponent implements IGrid, OnDestroy {
    forms: FormGroup[];
    colorsLines: any;
    currentID: any;
    InitReactiveFormData(): void;
    private getScreenNameFromHash;
    GetGridData(): void;
    ngOnDestroy(): void;
    EnableDisable_columns(colmnNames: string[], IsEditable: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiMasterGridDetailsChildrenComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiMasterGridDetailsChildrenComponent, "lib-bi-master-grid-details-children", never, { "forms": { "alias": "forms"; "required": false; }; "colorsLines": { "alias": "colorsLines"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BITreeComponent implements ITree {
    private translateService;
    treeViewElem: any;
    data: any[];
    DomID: string | undefined;
    textField: string;
    childrenField: string;
    filterable: boolean;
    size: 'small' | 'medium' | 'large';
    selectBy: string;
    selectedKeys: any[];
    selectionChange: EventEmitter<any>;
    blurChange: EventEmitter<any>;
    collapeChange: EventEmitter<any>;
    expandChange: EventEmitter<any>;
    filterChange: EventEmitter<any>;
    filterStateChange: EventEmitter<any>;
    focusChange: EventEmitter<any>;
    filterTerm: string;
    placeHolder: string;
    constructor(translateService: TranslateService);
    onSelectionChange({ index, dataItem }: any): void;
    onFocus(): void;
    onBlur(): void;
    onExpand(event: any): void;
    onCollapse(event: any): void;
    onFilterChange(event: string): void;
    onFilterStateChange(event: FilterState): void;
    hasChildren: (item: any) => any;
    fetchChildren: (item: any) => rxjs.Observable<any>;
    treeHasNoChildren(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BITreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BITreeComponent, "BI-tree", never, { "data": { "alias": "data"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; "textField": { "alias": "textField"; "required": false; }; "childrenField": { "alias": "childrenField"; "required": false; }; "filterable": { "alias": "filterable"; "required": false; }; "size": { "alias": "size"; "required": false; }; "selectBy": { "alias": "selectBy"; "required": false; }; "selectedKeys": { "alias": "selectedKeys"; "required": false; }; }, { "selectionChange": "selectionChange"; "blurChange": "blurChange"; "collapeChange": "collapeChange"; "expandChange": "expandChange"; "filterChange": "filterChange"; "filterStateChange": "filterStateChange"; "focusChange": "focusChange"; }, never, ["[embeddedContent]"], false, never>;
}

declare class BiAnchorPopupComponent implements IBiAnchorPopup {
    Width: string;
    Height: string;
    toggleText: string;
    show: boolean;
    onToggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiAnchorPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiAnchorPopupComponent, "bi-anchor-popup", never, { "Width": { "alias": "Width"; "required": false; }; "Height": { "alias": "Height"; "required": false; }; }, {}, never, ["*", ".anchor"], false, never>;
}

declare class biRenderValidatorMsgComponent {
    private translateService;
    formGroup: FormGroup;
    control: IControls;
    constructor(translateService: TranslateService);
    static ɵfac: i0.ɵɵFactoryDeclaration<biRenderValidatorMsgComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<biRenderValidatorMsgComponent, "bi-render-validator-msg", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "control": { "alias": "control"; "required": false; }; }, {}, never, never, false, never>;
}

type Handle = {
    id: string;
    api: Collapse;
    el: HTMLElement;
};
declare class ExpandCollapseRegistryService {
    private registry;
    private openIds;
    private toggleRendered;
    private _state$;
    state$: rxjs.Observable<{
        openCount: number;
        total: number;
    }>;
    register(h: Handle): void;
    unregister(id: string): void;
    expandAll(): void;
    collapseAll(): void;
    onShown(id: string): void;
    onHidden(id: string): void;
    shouldRenderToggleOnce(): boolean;
    resetToggleOnce(): void;
    private emitState;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandCollapseRegistryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExpandCollapseRegistryService>;
}

declare class biControlListin2ColComponent implements OnChanges, OnDestroy {
    private messages;
    biService: BIModulesService;
    ColViewService: ColViewService;
    private uiProfileService;
    private reg;
    AccordionName: string;
    accCollapse: ElementRef<HTMLDivElement>;
    date: moment.Moment;
    disabled: boolean;
    showSpinners: boolean;
    showSeconds: boolean;
    touchUi: boolean;
    enableMeridian: boolean;
    minDate: moment.Moment;
    maxDate: moment.Moment;
    stepHour: number;
    stepMinute: number;
    stepSecond: number;
    controlList: IControls[];
    formGroup: FormGroup;
    noOfRows: any;
    hasPendingChanges: boolean;
    ColsSizes: string[];
    IsFilterable: boolean | undefined;
    rowsList: string[];
    ColNumberServiceSub: Subscription;
    asFormControl(formControl: AbstractControl<any, any> | null): FormControl;
    mediaQueryLists: {
        [key: string]: MediaQueryList;
    };
    mediaQueryListeners: {
        [key: string]: () => void;
    };
    private breakpoints;
    matchedSize: string;
    private previousScreenSize;
    private columnNumber;
    private userUIProfileSub;
    constructor(messages: MessageService, biService: BIModulesService, ColViewService: ColViewService, uiProfileService: UiProfileService, reg: ExpandCollapseRegistryService);
    toggleHeader(): void;
    ngOnInit(): void;
    private determineSavedOrResponsiveLayout;
    changeColumnLayout(columnNumber: any): void;
    ngOnChanges(changes: SimpleChanges): void;
    AlterColumnNumber(numberOfColumns: number): void;
    rearrangeArray(items: any): any[];
    setupMediaQueries(): void;
    handleMediaQueryChange(): void;
    reArrangeColumns(): void;
    checkMatchedSize(): void;
    bindingData(event: any, name: string): void;
    returnDate(name: string): Date | null;
    ngOnDestroy(): void;
    preventInvalidInput(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<biControlListin2ColComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<biControlListin2ColComponent, "bi-control-list-2col", never, { "AccordionName": { "alias": "AccordionName"; "required": false; }; "controlList": { "alias": "controlList"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "noOfRows": { "alias": "noOfRows"; "required": false; }; "hasPendingChanges": { "alias": "hasPendingChanges"; "required": false; }; "ColsSizes": { "alias": "ColsSizes"; "required": false; }; "IsFilterable": { "alias": "IsFilterable"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIGridStepsComponent implements OnInit, AfterViewInit, IGridSteps {
    GridData: any[];
    Columns: IColumns[];
    ColumnsKey: string;
    GridId: string;
    multiselectFormGroup: FormGroup;
    RowDataChangeSubject$: Subject<unknown>;
    OrignalOrder: string;
    IsDirty: boolean;
    _DisableAll: boolean;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    asFormControl(formControl: AbstractControl<any, any> | null): FormControl;
    changeCheckBox(currentRow: any, colName: string): void;
    onMultiSelectChange(event: any, rowIndex: number, colName: string): void;
    PopPendingChanges(): boolean;
    DisableAll(value: boolean): void;
    FillOrignalOrder(GridData: any[]): void;
    cellClickHandler({ sender, rowIndex, column, columnIndex, dataItem, isEdited }: CellClickEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGridStepsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGridStepsComponent, "BI-GridSteps", never, { "GridData": { "alias": "GridData"; "required": false; }; "Columns": { "alias": "Columns"; "required": false; }; "ColumnsKey": { "alias": "ColumnsKey"; "required": false; }; "GridId": { "alias": "GridId"; "required": false; }; "multiselectFormGroup": { "alias": "multiselectFormGroup"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIGalleryComponent implements IGallery, OnChanges {
    sanitizer: DomSanitizer;
    private translate;
    loggerService: LoggerService;
    mode: 'single' | 'multiple';
    data: any[];
    uploadingProgress: any;
    DomID: any;
    keyId: string;
    saveURL: string;
    viewMode: boolean;
    src: string;
    uploadRestrictions: FileRestrictions;
    CustomUploadRestrictions: any;
    selectedImage: any;
    isBanner: boolean;
    onDeleteImage: EventEmitter<any>;
    AfterAddImage: EventEmitter<any>;
    OnSelect: EventEmitter<any>;
    selectedIndex: number;
    errorMessages: string[];
    selectedImageData: any;
    previewSrc: string;
    constructor(sanitizer: DomSanitizer, translate: TranslateService, loggerService: LoggerService);
    ngOnChanges(changes: SimpleChanges): void;
    deleteImage(imageData: any): void;
    selectImage(image: any, index: number): void;
    prev(): void;
    next(): void;
    onSelectImg(ev: SelectEvent, uploader: UploadComponent): void;
    SetErrorMessages(ev: SelectEvent): void;
    HasCustomRestrictions(): boolean;
    CheckCustomRestrictions(ev: SelectEvent, image: any): void;
    onclick(): void;
    imageAddedSuccessfully(event: any): void;
    uploadProgressEventHandler(e: UploadProgressEvent): void;
    alertShow(content: string, type: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGalleryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGalleryComponent, "BI-gallery", never, { "mode": { "alias": "mode"; "required": false; }; "data": { "alias": "data"; "required": false; }; "uploadingProgress": { "alias": "uploadingProgress"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; "keyId": { "alias": "keyId"; "required": false; }; "saveURL": { "alias": "saveURL"; "required": false; }; "viewMode": { "alias": "viewMode"; "required": false; }; "src": { "alias": "src"; "required": false; }; "uploadRestrictions": { "alias": "uploadRestrictions"; "required": false; }; "CustomUploadRestrictions": { "alias": "CustomUploadRestrictions"; "required": false; }; "selectedImage": { "alias": "selectedImage"; "required": false; }; "isBanner": { "alias": "isBanner"; "required": false; }; }, { "onDeleteImage": "onDeleteImage"; "AfterAddImage": "AfterAddImage"; "OnSelect": "OnSelect"; }, never, never, false, never>;
}

declare class biControlListComponent implements OnChanges {
    controlList: IControls[];
    formGroup: FormGroup;
    noOfRows: number;
    rowsList: string[];
    asFormControl(formControl: AbstractControl<any, any> | null): FormControl;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    fillRowsList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<biControlListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<biControlListComponent, "bi-control-list", never, { "controlList": { "alias": "controlList"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "noOfRows": { "alias": "noOfRows"; "required": false; }; }, {}, never, never, false, never>;
}

declare class SidebarSearchResultsComponent {
    routeNavigated: EventEmitter<any>;
    searchResults: ISearchItem[];
    searchValue: string;
    contentView: 'mainMenu' | 'subMenu';
    constructor();
    navigateToScreen(item: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarSearchResultsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarSearchResultsComponent, "sidebar-search-results", never, { "searchResults": { "alias": "searchResults"; "required": false; }; "searchValue": { "alias": "searchValue"; "required": false; }; "contentView": { "alias": "contentView"; "required": false; }; }, { "routeNavigated": "routeNavigated"; }, never, never, false, never>;
}

declare class BiPhotoUploaderComponent implements IPhotoUploader {
    sanitizer: DomSanitizer;
    private translateService;
    photoUploader: UploadComponent;
    uploadPhotoClicked: EventEmitter<any>;
    selectPhotoClicked: EventEmitter<any>;
    completeUpload: EventEmitter<any>;
    clearPhotoClicked: EventEmitter<any>;
    LabelName: string;
    BindingProperty: FormControl;
    MainFormGroup: FormGroup;
    UploadRestrictions: FileRestrictions;
    ClearBtnDisabled: boolean;
    UploadBtnDisabled: boolean;
    AutoUpload: boolean;
    SaveUrl: any;
    previewSrc: string | any;
    invalidImage: boolean;
    src: string;
    constructor(sanitizer: DomSanitizer, translateService: TranslateService);
    clearPhoto(): void;
    uploadPhoto(event: any): void;
    selectPhoto(event: SelectEvent): void;
    complete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiPhotoUploaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiPhotoUploaderComponent, "bi-photo-uploader", never, { "LabelName": { "alias": "LabelName"; "required": false; }; "BindingProperty": { "alias": "BindingProperty"; "required": false; }; "MainFormGroup": { "alias": "MainFormGroup"; "required": false; }; "UploadRestrictions": { "alias": "UploadRestrictions"; "required": false; }; "ClearBtnDisabled": { "alias": "ClearBtnDisabled"; "required": false; }; "UploadBtnDisabled": { "alias": "UploadBtnDisabled"; "required": false; }; "AutoUpload": { "alias": "AutoUpload"; "required": false; }; "SaveUrl": { "alias": "SaveUrl"; "required": false; }; }, { "uploadPhotoClicked": "uploadPhotoClicked"; "selectPhotoClicked": "selectPhotoClicked"; "completeUpload": "completeUpload"; "clearPhotoClicked": "clearPhotoClicked"; }, never, never, false, never>;
}

declare class ColorStatusDirective implements OnChanges {
    private el;
    private renderer;
    dataInput: any;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorStatusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ColorStatusDirective, "[colorStatus]", never, { "dataInput": { "alias": "colorStatus"; "required": false; }; }, {}, never, never, false, never>;
}

declare class InCellTabDirective implements OnInit, OnDestroy {
    private grid;
    private el;
    private renderer;
    createFormGroup: (args: CreateFormGroupArgs) => FormGroup;
    wrap: boolean;
    private unsubKeydown;
    constructor(grid: GridComponent, el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onKeydown(e: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InCellTabDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InCellTabDirective, "[inCellTab]", never, { "createFormGroup": { "alias": "inCellTab"; "required": false; }; "wrap": { "alias": "wrap"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BiLogoGalleryComponent extends BIGalleryComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BiLogoGalleryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiLogoGalleryComponent, "BI-Logo-Gallery", never, {}, {}, never, never, false, never>;
}

declare class BiAttachmentsComponent implements AfterViewInit {
    _datasource: any;
    _changeset: any;
    private router;
    translateService: TranslateService;
    biService: BIModulesService;
    sanitizer: DomSanitizer;
    loggerService: LoggerService;
    BIGrid: IGrid;
    ActionClicked: EventEmitter<any>;
    data: {
        BIGrid: IGrid;
        CanViewAttachments: boolean;
        CanAddAttachments: boolean;
        CanDeleteAttachments: boolean;
        StorageLocation: 0 | 1 | null;
    };
    Params: {
        Name: string;
        Operator: string;
        value: string;
        DataType: DataTypes;
    }[];
    isImage: boolean;
    isViewClicked: boolean;
    isUploadSuccessful: boolean;
    deleteConfirmMsg: boolean;
    EntityName: string;
    file: any;
    UploadedFile: any;
    SA_Attachments_DataSource: any;
    SA_Attachments_changeset: any;
    SA_Attachments_columns: IColumns[];
    AttachmentTypeDef_DataSource: any;
    navButtons: INavBtn;
    constructor(_datasource: any, _changeset: any, router: Router, translateService: TranslateService, biService: BIModulesService, sanitizer: DomSanitizer, loggerService: LoggerService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    HeaderRowChange(): void;
    FilterAttachments(): void;
    UploadFile(event: any): void;
    GetImage(): any;
    Download(): Promise<void>;
    View(): Promise<void>;
    ViewCanceled(): void;
    OnCancel(): void;
    /**
     * delete row from the grid
     * @return void
     */
    DeleteRow(): void;
    /**
     * save edits in any cell
     * @return void
     */
    Cancel(): void;
    /**
     * save edits in any cell
     * @return void
     */
    Save(): void;
    alertShow(content: string, type: number): void;
    GenaricLookupAttachmentTypeDefInitialization(AttachmentTypeDef: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiAttachmentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiAttachmentsComponent, "app-bi-attachments", never, {}, {}, never, never, false, never>;
}

declare class PasswordPipe implements PipeTransform {
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PasswordPipe, "password", false>;
}

declare class BiMasterGridComposedComponent extends BiMasterGridDetailsComponent implements IGrid {
    Getvalue(DataITem: any): any;
    insertDataItemInRow(args: any): void;
    BGridDetailsChildren_BeforeAddRow(dataItem: any): void;
    filterInRefrenceChildren(dataItem: any, rowIndex: number): any;
    EnableDisableGrid(IsEditable: boolean, dataItem: any): void;
    expandDetailsBy: (dataItem: any) => number;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiMasterGridComposedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiMasterGridComposedComponent, "lib-bi-master-grid-composed", never, {}, {}, never, never, false, never>;
}

declare class BiCardFilterComponent implements ICardFilter, AfterViewInit {
    myBiser: BIModulesService;
    mymess: MessageService;
    constructor(myBiser: BIModulesService, mymess: MessageService);
    state: State;
    data: {
        value: CompositeFilterDescriptor;
        Columns: any;
        Dialog: any;
    };
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onFilterChange(value: CompositeFilterDescriptor): void;
    editorValueChange(value: any, currentItem: FilterDescriptor, filterValue: CompositeFilterDescriptor): void;
    lookupValueChange(value: any, key: any, currentItem: FilterDescriptor, filterValue: CompositeFilterDescriptor): void;
    RadioValueChange(value: any, currentItem: FilterDescriptor, filterValue: CompositeFilterDescriptor): void;
    OnOk(): void;
    OnCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiCardFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiCardFilterComponent, "bi-card-filter", never, {}, {}, never, never, false, never>;
}

declare enum LoadingMode {
    Lazy = "Lazy",
    Eager = "Eager"
}
declare enum StatusAction {
    ADD = "Add",
    UPDATE = "Update",
    NOP = "NOP",
    Delete = "Delete"
}
declare class BiCardsComponent implements ICards, AfterViewInit, OnChanges {
    formBuilder: FormBuilder;
    biService: BIModulesService;
    messages: MessageService;
    translateService: TranslateService;
    private cd;
    getValuePipe: GetValuePipe;
    errorDetailsService: ErrorDetailsService;
    loggerService: LoggerService;
    private elementRef;
    CardTemplate: any;
    HeaderTemplate: TemplateRef<any>;
    FooterTemplate: TemplateRef<any>;
    DataService: IDataSource;
    CardsListDVH: number;
    LoadingMode: LoadingMode;
    CardEditTemplate: any;
    Columns: IColumns[];
    changeSet: IChangeset;
    HasExport: boolean;
    ExportFileName: string;
    EnableCRUD: boolean;
    IsChild: boolean;
    DomID: string;
    CellClose: EventEmitter<any>;
    OnCardChange: EventEmitter<any>;
    OnAddRow: EventEmitter<any>;
    OnCloseRow: EventEmitter<any>;
    AfterSave: EventEmitter<any>;
    AfterCancel: EventEmitter<any>;
    AfterLoad: EventEmitter<any>;
    AfterAddRow: EventEmitter<any>;
    AfterAdd: EventEmitter<any>;
    OnSort: EventEmitter<any>;
    listViewItem: ListViewComponent;
    CardsListHeight: string;
    IneditMode: Map<string, boolean>;
    _filters: string;
    private _sorters;
    private IsInScroll;
    private CardData;
    private CardDataSubscription;
    StopSaveSubscription: Subscription;
    StopDeleteSubscription: Subscription;
    DeleteSubscription: Subscription;
    AddSubscription: Subscription;
    GridDataSubscription: Subscription;
    view: any[];
    data: any[];
    form: any;
    RowIdentifier: string;
    ChangeSet_Status: string;
    CurrentSelectRow: FormGroup;
    rowCol: IColumns;
    Status: IColumns;
    formGroups: ExtendedMap;
    currentEditingCard: any;
    editedFormGrop: any;
    DefaultValue: any;
    statusAction: StatusAction;
    AllowSave: Subject<boolean>;
    AllowDelete: Subject<boolean>;
    AllowAdd: Subject<boolean>;
    RowCount: number;
    ExportToExcel(): void;
    constructor(formBuilder: FormBuilder, biService: BIModulesService, messages: MessageService, translateService: TranslateService, cd: ChangeDetectorRef, getValuePipe: GetValuePipe, errorDetailsService: ErrorDetailsService, loggerService: LoggerService, elementRef: ElementRef);
    private resizeObserver;
    private mutationObserver;
    onResize(): void;
    private scheduled;
    private scheduleCalculateHeight;
    calculateHeight(): void;
    ngAfterViewInit(): void;
    initializeObservers(): void;
    private setupObservers;
    SetValue(ColumnName: string, Value: any, MarkAsDirty?: boolean): void;
    GetValueOf(Name: string): any;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    initCardForm(): void;
    PushChangesArr(): void;
    getCardData(): void;
    loadMore(): void;
    set filters(filter: string);
    SetInternalFilter(filter: string): void;
    set sorter(sorter: string);
    read(): void;
    GetNewRowID(): string;
    InitReactiveFormData(): void;
    setDefaultDate(form: any): void;
    handleFormGroup(): void;
    GetRowValue(): any;
    DeleteRow(): Promise<void>;
    AddRow(): void;
    ValidateDirtyBeforeSave(formgroups: ExtendedMap): void;
    CheckPendingChange(): boolean;
    IsDirty(formGroups: ExtendedMap): boolean;
    IsDirtyAndCheckValid(formGroups: ExtendedMap): boolean;
    EditSaveSubscription: Subscription;
    DoUpdate(): void;
    Save(): Promise<void>;
    saveAll(): Promise<void>;
    BeforeActionSave(): BeforeAction;
    _ConvertBoolean2Number(formGroup: FormGroup): void;
    PrepareBodyReq(data: any): any;
    GetUpdatedProperties(myForm: FormGroup<any> | undefined): any;
    HandleParamsApiRequest(Value: any): string;
    HandleFormateTypeKeysReq(Key: string, Value: any): any;
    getTypeFilter(Key: string): DataTypes | undefined;
    HandleFilterApiRequest(response: any): string;
    alertShow(content: string, type: number): void;
    closeRow(rowIndex?: number): void;
    AfterActionSave(): void;
    DoAdd(): void;
    ResetRowUpdateStatus(): void;
    BeforeActionDelete(): BeforeAction;
    Cancel(): void;
    ConvertBoolean2Number(): void;
    ngOnDestroy(): void;
    CardChange(rowid: any, EnterEditMode?: boolean): void;
    CloseAll(): boolean;
    CloseCard(rowid: any): boolean;
    private SyncViewItem;
    EnterEditMode(dataItem: any): void;
    private FocusMarkedField;
    ExitEditMode(dataItem: any): void;
    EnableDisable_columns(colmnNames: string[], IsEditable: boolean): void;
    ClearGrid(): void;
    RefreshCurrentRow(AfterRefreshFunc: Function): Subscription;
    ResetScroll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiCardsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiCardsComponent, "bi-cards", never, { "CardTemplate": { "alias": "CardTemplate"; "required": false; }; "HeaderTemplate": { "alias": "HeaderTemplate"; "required": false; }; "FooterTemplate": { "alias": "FooterTemplate"; "required": false; }; "DataService": { "alias": "DataService"; "required": false; }; "CardsListDVH": { "alias": "CardsListDVH"; "required": false; }; "LoadingMode": { "alias": "LoadingMode"; "required": false; }; "CardEditTemplate": { "alias": "CardEditTemplate"; "required": false; }; "Columns": { "alias": "Columns"; "required": false; }; "changeSet": { "alias": "changeSet"; "required": false; }; "HasExport": { "alias": "HasExport"; "required": false; }; "ExportFileName": { "alias": "ExportFileName"; "required": false; }; "EnableCRUD": { "alias": "EnableCRUD"; "required": false; }; "IsChild": { "alias": "IsChild"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; }, { "CellClose": "CellClose"; "OnCardChange": "OnCardChange"; "OnAddRow": "OnAddRow"; "OnCloseRow": "OnCloseRow"; "AfterSave": "AfterSave"; "AfterCancel": "AfterCancel"; "AfterLoad": "AfterLoad"; "AfterAddRow": "AfterAddRow"; "AfterAdd": "AfterAdd"; "OnSort": "OnSort"; }, never, never, false, never>;
}

declare class FilterCacheService {
    private readonly storageKey;
    save(gridId: string, filters: any): void;
    get(gridId: string): any;
    clearAll(): void;
    private getAll;
    private getUserName;
    private buildKey;
    private getScreenUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterCacheService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FilterCacheService>;
}

declare class BiCardNavComponent implements ICardNav, AfterViewInit, OnChanges {
    _dialog: any;
    translateService: TranslateService;
    private bottomSheet;
    private uiProfileService;
    private filterCacheService;
    filter: CompositeFilterDescriptor;
    sorter: SortDescriptor;
    private searchDecouncer$;
    private mobileColumnsSource;
    isSorterOpen: boolean;
    gridKeys: string[];
    searchText: string;
    FilterDialog: CreateDialog;
    SorterDialog: CreateDialog;
    isFilterActive: boolean;
    isSorterActive: boolean;
    isRefreshActive: boolean;
    isColumnsActive: boolean;
    isCustomFilter: boolean;
    isCustomSorter: boolean;
    PageTitle: string;
    RowTitle: string;
    CardList: ICards;
    Columns: IColumns[];
    navButtons: INavBtn;
    CanInsert: boolean;
    CanUpdate: boolean;
    CanDelete: boolean;
    CanViewAttachments: boolean;
    CanAddAttachments: boolean;
    CanDeleteAttachments: boolean;
    beforeApplyFilter?: (state: any) => void;
    ActionClicked: EventEmitter<any>;
    DomID: string;
    CustomFilter: EventEmitter<any>;
    CustomSorter: EventEmitter<any>;
    AfterCancel: EventEmitter<any>;
    deleteConfirmMsg: boolean;
    SectionTitle: boolean;
    SearchPlaceholder: string;
    showAppliedFiltersBar: boolean;
    constructor(_dialog: any, translateService: TranslateService, bottomSheet: MatBottomSheet, uiProfileService: UiProfileService, filterCacheService: FilterCacheService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private rebuildFilterColumns;
    private applyUserColumnsConfigs;
    private ensureMinimumCollapsedColumns;
    isShownCollapsed(...fieldNames: string[]): boolean;
    isShownExpanded(...fieldNames: string[]): boolean;
    private isMobileFieldVisible;
    private isRequiredMobileField;
    private getMobileColumn;
    private hasRequiredValidator;
    refresh(): void;
    FilterSubscribtion: Subscription;
    OnOpenFilter(): void;
    OnFilter(state: any): void;
    get appliedFilters(): any[];
    removeAppliedFilter(filterToRemove: any): void;
    clearAllAppliedFilters(): void;
    getColumnDisplayName(fieldName: string): string;
    SorterSubscribtion: Subscription;
    OnOpenSorter(): void;
    OnSort(state: any): void;
    AddRow(): void;
    Save(): void;
    DeleteCard(): void;
    Cancel(): void;
    onSearchChange(value: string): void;
    Search(): void;
    getGridKeys(): string[];
    openMobileColumnCustomizer(): void;
    onMobileColumnsChange(columns: IColumns[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiCardNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiCardNavComponent, "bi-card-nav", never, { "isFilterActive": { "alias": "isFilterActive"; "required": false; }; "isSorterActive": { "alias": "isSorterActive"; "required": false; }; "isRefreshActive": { "alias": "isRefreshActive"; "required": false; }; "isColumnsActive": { "alias": "isColumnsActive"; "required": false; }; "isCustomFilter": { "alias": "isCustomFilter"; "required": false; }; "isCustomSorter": { "alias": "isCustomSorter"; "required": false; }; "PageTitle": { "alias": "PageTitle"; "required": false; }; "RowTitle": { "alias": "RowTitle"; "required": false; }; "CardList": { "alias": "CardList"; "required": false; }; "Columns": { "alias": "Columns"; "required": false; }; "navButtons": { "alias": "navButtons"; "required": false; }; "CanInsert": { "alias": "CanInsert"; "required": false; }; "CanUpdate": { "alias": "CanUpdate"; "required": false; }; "CanDelete": { "alias": "CanDelete"; "required": false; }; "CanViewAttachments": { "alias": "CanViewAttachments"; "required": false; }; "CanAddAttachments": { "alias": "CanAddAttachments"; "required": false; }; "CanDeleteAttachments": { "alias": "CanDeleteAttachments"; "required": false; }; "beforeApplyFilter": { "alias": "beforeApplyFilter"; "required": false; }; "DomID": { "alias": "DomID"; "required": false; }; "deleteConfirmMsg": { "alias": "deleteConfirmMsg"; "required": false; }; "SectionTitle": { "alias": "SectionTitle"; "required": false; }; "SearchPlaceholder": { "alias": "SearchPlaceholder"; "required": false; }; "showAppliedFiltersBar": { "alias": "showAppliedFiltersBar"; "required": false; }; }, { "ActionClicked": "ActionClicked"; "CustomFilter": "CustomFilter"; "CustomSorter": "CustomSorter"; "AfterCancel": "AfterCancel"; }, never, ["[section-title]", ":not([section-title])", "right-content"], false, never>;
}

declare class BiCardSorterComponent implements ICardSorter, AfterViewInit {
    translateService: TranslateService;
    myBiser: BIModulesService;
    mymess: MessageService;
    state: State;
    SortingOrder: "asc" | "desc" | undefined;
    data: {
        value: SortDescriptor[];
        Columns: IColumns[];
        Dialog: any;
    };
    constructor(translateService: TranslateService, myBiser: BIModulesService, mymess: MessageService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    editorValueChange(ColumnName: any): void;
    OnOk(): void;
    OnCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiCardSorterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiCardSorterComponent, "bi-card-sorter", never, {}, {}, never, never, false, never>;
}

declare class BiFloatingInputsComponent {
    private translateService;
    biService: BIModulesService;
    Control: IControls;
    FormGroup: FormGroup;
    Type: string;
    FormControl: FormControl;
    constructor(translateService: TranslateService, biService: BIModulesService);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiFloatingInputsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiFloatingInputsComponent, "bi-floating-inputs", never, { "Control": { "alias": "Control"; "required": false; }; "FormGroup": { "alias": "FormGroup"; "required": false; }; "Type": { "alias": "Type"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ValidationErrorToolTipComponent {
    private translateService;
    biService: BIModulesService;
    Control: IControls;
    FormControl: FormControl;
    ControlType: string;
    LookupIncorrectErrorMsg: string;
    constructor(translateService: TranslateService, biService: BIModulesService);
    getErrorMessage(FormControl: any): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationErrorToolTipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ValidationErrorToolTipComponent, "validation-error-tool-tip", never, { "Control": { "alias": "Control"; "required": false; }; "FormControl": { "alias": "FormControl"; "required": false; }; "ControlType": { "alias": "ControlType"; "required": false; }; "LookupIncorrectErrorMsg": { "alias": "LookupIncorrectErrorMsg"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BiFloatingColorPickerComponent {
    FormControl: FormControl;
    Control: IControls;
    hexaDecimalColor: string | null;
    InputColor: ElementRef | any;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setColor(formControl: any): void;
    RemoveColor(event: any, formControl: any): void;
    rgbStringToHex(rgbString: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiFloatingColorPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiFloatingColorPickerComponent, "bi-floating-color-picker", never, { "FormControl": { "alias": "FormControl"; "required": false; }; "Control": { "alias": "Control"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BiFloatingTextAreaComponent {
    private translateService;
    biService: BIModulesService;
    Control: IControls;
    FormGroup: FormGroup;
    FormControl: FormControl;
    constructor(translateService: TranslateService, biService: BIModulesService);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiFloatingTextAreaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiFloatingTextAreaComponent, "bi-floating-text-area", never, { "Control": { "alias": "Control"; "required": false; }; "FormGroup": { "alias": "FormGroup"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIGridColumnCustomizerComponent implements OnInit, IDialog {
    private uiProfileService;
    data: any;
    outputValue: any;
    gridKeys: string[];
    tempColumns: IColumns[];
    constructor(uiProfileService: UiProfileService);
    ngOnInit(): void;
    drop(event: CdkDragDrop<IColumns[]>): void;
    OnItemVisibilityChanges(column: IColumns, event: Event): void;
    NotifyParent(): void;
    OnOk(): void;
    OnCancel(onclose: boolean): void;
    OnSetAsDefault(): void;
    isRequiredColumn(itemValidators: ValidatorFn | Array<ValidatorFn> | undefined | null): boolean;
    isDisabled(col: IColumns): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGridColumnCustomizerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGridColumnCustomizerComponent, "bi-grid-column-customizer", never, {}, {}, never, never, false, never>;
}

declare class BiReportMangerMenuComponent implements OnInit {
    _datasource: any;
    private translate;
    private formBuilder;
    private activatedRoute;
    private route;
    reportMangerList: any;
    selectedItem: string;
    items: any;
    collapsed: boolean;
    isRight: boolean;
    selectedMenuItem: string[];
    activeButton: any;
    childExpandedPanels: {
        [key: string]: number;
    };
    constructor(_datasource: any, translate: TranslateService, formBuilder: FormBuilder, activatedRoute: ActivatedRoute, route: Router);
    ngOnInit(): void;
    setActiveButton(buttonText: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiReportMangerMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiReportMangerMenuComponent, "bi-report-manger-menu", never, { "reportMangerList": { "alias": "reportMangerList"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "items": { "alias": "items"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "isRight": { "alias": "isRight"; "required": false; }; "selectedMenuItem": { "alias": "selectedMenuItem"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BiChildReportComponent {
    private router;
    ChildReports: any;
    isRight: boolean;
    selectedItem: string;
    collapsed: boolean;
    selectedMenuItem: string[];
    activeButton: any;
    childExpandedPanels: {
        [key: string]: number;
    };
    constructor(router: Router);
    navigateToScreen(path: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiChildReportComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiChildReportComponent, "bi-child-report", never, { "ChildReports": { "alias": "ChildReports"; "required": false; }; "isRight": { "alias": "isRight"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "selectedMenuItem": { "alias": "selectedMenuItem"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BIFavoriteButtonComponent implements OnInit, OnDestroy {
    private uiProfileService;
    private router;
    selected: boolean;
    private routerEventSub;
    constructor(uiProfileService: UiProfileService, router: Router);
    ngOnInit(): void;
    toggleSelected(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BIFavoriteButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIFavoriteButtonComponent, "bi-favorite-button", never, {}, {}, never, never, false, never>;
}

declare class BIGridGenericDataTypeComponent extends BIGridComponent {
    /**
   * A dictionary that maps column names to their respective dependent column that contains their data types.
   *
   * This object enables defining specific data types for each row,
   * where each key represents a column name, and each value specifies
   * the column that contains the datatype expected for that column.
   *
   * Example usage:
   * ```
   * this.columnDataTypes["UpperValue"] = "ValueDataType";
   * ```
   * where UpperValue is the column and ValueDataType is the column that contains its datatype
   *
   * @type {{ [key: string]: string }}
   */
    columnDataTypes: {
        [key: string]: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<BIGridGenericDataTypeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BIGridGenericDataTypeComponent, "BI-Grid-generic-data-type", never, { "columnDataTypes": { "alias": "columnDataTypes"; "required": false; }; }, {}, never, never, false, never>;
}

declare class LocalizedNumberPipe implements PipeTransform {
    private decimalPipe;
    constructor(decimalPipe: DecimalPipe);
    transform(value: number | string | null | undefined, precision?: number): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalizedNumberPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LocalizedNumberPipe, "localizedNumber", false>;
}

declare class BiInfoButtonComponent implements IDialog {
    data: any;
    outputValue: any;
    OnOk(): void;
    OnCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiInfoButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiInfoButtonComponent, "lib-bi-info-button", never, {}, {}, never, never, false, never>;
}

declare class DateDisplayDirective implements OnChanges {
    private elementRef;
    private datePipe;
    dateDisplay: string;
    dateValue: any;
    constructor(elementRef: ElementRef, datePipe: DatePipe);
    ngOnChanges(changes: SimpleChanges): void;
    private updateDisplay;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateDisplayDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DateDisplayDirective, "[dateDisplay]", never, { "dateDisplay": { "alias": "dateDisplay"; "required": false; }; "dateValue": { "alias": "dateValue"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BiAccordionDirective implements OnInit, OnDestroy {
    private elRef;
    private reg;
    private id;
    private api;
    constructor(elRef: ElementRef<HTMLElement>, reg: ExpandCollapseRegistryService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiAccordionDirective, [null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BiAccordionDirective, "[biAccordion]", never, {}, {}, never, never, false, never>;
}

declare class BiMatTabAutoResetDirective {
    private group;
    private ec;
    constructor(group: MatTabGroup, ec: ExpandCollapseRegistryService);
    static ɵfac: i0.ɵɵFactoryDeclaration<BiMatTabAutoResetDirective, [{ optional: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BiMatTabAutoResetDirective, "mat-tab-group", never, {}, {}, never, never, false, never>;
}

declare class BiAccordionScopeDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<BiAccordionScopeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BiAccordionScopeDirective, "mat-tab, mat-tab-body, .mat-mdc-tab-body, .mat-mdc-tab-body-content, .mat-tab-body-content, .tab-pane, [biAccordionScope]", never, {}, {}, never, never, false, never>;
}

declare class BiAccordionToolbarDirective implements OnInit, OnDestroy {
    private host;
    private r;
    private translate;
    private reg;
    private bar;
    private link;
    private sub?;
    private lastState?;
    constructor(host: ElementRef<HTMLElement>, r: Renderer2, translate: TranslateService, reg: ExpandCollapseRegistryService);
    private updateToggleText;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiAccordionToolbarDirective, [null, null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BiAccordionToolbarDirective, ".accordion", never, {}, {}, never, never, false, never>;
}

declare class NumericKeyboardDirective implements AfterViewInit {
    private el;
    constructor(el: ElementRef);
    ngAfterViewInit(): void;
    private applyAttributes;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumericKeyboardDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NumericKeyboardDirective, "[numericKeyboard]", never, {}, {}, never, never, false, never>;
}

type CustomizerColumn = IColumns & {
    IsRequired?: boolean;
};
declare class BiMobileColumnCustomizerComponent implements OnInit, OnChanges, OnDestroy {
    private bottomSheetRef;
    data: {
        domId: string;
        columns: IColumns[];
        gridKeys: string[];
    };
    private translateService;
    private cdr;
    private uiProfileService;
    columns: CustomizerColumn[];
    gridKeys: string[];
    hiddenColumns: CustomizerColumn[];
    shownCollapsedColumns: CustomizerColumn[];
    shownExpandedColumns: CustomizerColumn[];
    currentDirection: 'rtl' | 'ltr';
    showValidationError: boolean;
    get COLLAPSED_LIMIT(): number;
    private langChangeSubscription?;
    constructor(bottomSheetRef: MatBottomSheetRef<BiMobileColumnCustomizerComponent>, data: {
        domId: string;
        columns: IColumns[];
        gridKeys: string[];
    }, translateService: TranslateService, cdr: ChangeDetectorRef, uiProfileService: UiProfileService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private syncSections;
    private updateDirection;
    private hasRequiredValidator;
    drop(event: CdkDragDrop<CustomizerColumn[]>): void;
    private validateColumnsCount;
    onClose(): void;
    onSetAsDefault(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BiMobileColumnCustomizerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BiMobileColumnCustomizerComponent, "bi-mobile-column-customizer", never, {}, {}, never, never, false, never>;
}

declare class BIModulesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BIModulesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BIModulesModule, [typeof BiNavComponent, typeof BIChildGridGenericDataTypeComponent, typeof BIGridComponent, typeof BIChildGridComponent, typeof BIGridLayoutComponent, typeof BIGridLayoutItemComponent, typeof BISideBarComponent, typeof SideBarContentComponent, typeof BILookupComponent, typeof BIModalComponent, typeof BiDropDownComponent, typeof GetValuePipe, typeof GetGenericValuePipe, typeof GetChildGenericValuePipe, typeof filterValuesPipe, typeof BIDatePickerComponent, typeof BIPopupComponent, typeof ErrorMessageComponent, typeof SideBarErrorDetailsComponent, typeof DialogDirective, typeof BiDialog, typeof NegativeValueTransformPipe, typeof BiMasterGridDetailsComponent, typeof BiMasterGridDetailsChildrenComponent, typeof BITreeComponent, typeof BiAnchorPopupComponent, typeof biRenderValidatorMsgComponent, typeof biControlListin2ColComponent, typeof BIGridStepsComponent, typeof BIGalleryComponent, typeof biControlListComponent, typeof BIPopupMenuComponent, typeof BISearchComponent, typeof SidebarSearchResultsComponent, typeof BiPhotoUploaderComponent, typeof ColorStatusDirective, typeof InCellTabDirective, typeof BiLogoGalleryComponent, typeof BiAttachmentsComponent, typeof PasswordPipe, typeof BiMasterGridComposedComponent, typeof BiCardFilterComponent, typeof BiCardsComponent, typeof BiCardNavComponent, typeof BiCardSorterComponent, typeof BiFloatingInputsComponent, typeof ValidationErrorToolTipComponent, typeof BiFloatingDropDownComponent, typeof BiFloatingLookupComponent, typeof BiFloatingColorPickerComponent, typeof BiFloatingTextAreaComponent, typeof BIGridColumnCustomizerComponent, typeof BiReportMangerMenuComponent, typeof BiChildReportComponent, typeof BIFavoriteButtonComponent, typeof BIGridGenericDataTypeComponent, typeof LocalizedNumberPipe, typeof BiMultiSelectComponent, typeof BiInfoButtonComponent, typeof DateDisplayDirective, typeof BiAccordionDirective, typeof BiMatTabAutoResetDirective, typeof BiAccordionScopeDirective, typeof BiAccordionToolbarDirective, typeof NumericKeyboardDirective, typeof BiMobileColumnCustomizerComponent], [typeof i67.AlertModule, typeof i68.IconsModule, typeof i69.DateInputsModule, typeof i70.GridModule, typeof i71.ReactiveFormsModule, typeof i72.PagerModule, typeof i73.FilterModule, typeof i74.LayoutModule, typeof i75.DropDownsModule, typeof i71.FormsModule, typeof i76.DialogsModule, typeof i77.InputsModule, typeof i78.ButtonsModule, typeof i79.PopupModule, typeof i77.NumericTextBoxModule, typeof i80.MatSnackBarModule, typeof i81.MatTooltipModule, typeof i82.TranslateModule, typeof i83.IntlModule, typeof i84.MatDatepickerModule, typeof i85.MatDialogModule, typeof i86.MatNativeDateModule, typeof i87.TreeViewModule, typeof i88.BIInterfacesModule, typeof i89.UploadsModule, typeof i90.NgxMaskPipe, typeof i90.NgxMaskDirective, typeof i91.FloatingLabelModule, typeof i70.ExcelModule, typeof i74.LayoutModule, typeof i92.ListViewModule, typeof i93.MatRadioModule, typeof i94.MatInputModule, typeof i95.MatSelectModule, typeof i96.MatFormFieldModule, typeof i97.MatIconModule, typeof i98.MatMenuModule, typeof i99.CdkDrag, typeof i99.CdkDropList, typeof i99.CdkDropListGroup, typeof i100.CommonModule, typeof i101.MatMomentDateModule, typeof i102.NgxMatDatepickerInput, typeof i102.NgxMatDatetimepicker, typeof i103.MatChipsModule, typeof i104.MatBadgeModule, typeof i105.MatBottomSheetModule], [typeof BiNavComponent, typeof BIGridLayoutComponent, typeof BIGridLayoutItemComponent, typeof BISideBarComponent, typeof SideBarContentComponent, typeof BILookupComponent, typeof i82.TranslateModule, typeof BIGridComponent, typeof BIChildGridComponent, typeof BiDropDownComponent, typeof BIModalComponent, typeof BIPopupComponent, typeof ErrorMessageComponent, typeof SideBarErrorDetailsComponent, typeof BiMasterGridDetailsComponent, typeof BiMasterGridComposedComponent, typeof BITreeComponent, typeof BiAnchorPopupComponent, typeof biControlListin2ColComponent, typeof BIGridStepsComponent, typeof BIGalleryComponent, typeof BiLogoGalleryComponent, typeof biControlListComponent, typeof BIPopupMenuComponent, typeof BiPhotoUploaderComponent, typeof BiCardsComponent, typeof BiFloatingLookupComponent, typeof BiFloatingDropDownComponent, typeof BiCardFilterComponent, typeof BiCardNavComponent, typeof BIFavoriteButtonComponent, typeof BIGridGenericDataTypeComponent, typeof BIChildGridGenericDataTypeComponent, typeof BiMultiSelectComponent, typeof BiAccordionDirective, typeof BiMatTabAutoResetDirective, typeof BiAccordionScopeDirective, typeof BiAccordionToolbarDirective, typeof NumericKeyboardDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BIModulesModule>;
}

declare class NotificationService {
    constructor();
    notifyMe(options: INotificationOption): void;
    requestNotificationPermission(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotificationService>;
}
interface INotificationOption {
    Title: string;
    Body?: string;
    Icon?: string;
    OnShow?: Function;
    OnClick?: Function;
}

export { BIChildGridComponent, BIChildGridGenericDataTypeComponent, BIDatePickerComponent, BIFavoriteButtonComponent, BIGalleryComponent, BIGridComponent, BIGridGenericDataTypeComponent, BIGridLayoutComponent, BIGridLayoutItemComponent, BIGridStepsComponent, BILookupComponent, BIModalComponent, BIModulesModule, BIModulesService, BIPopupComponent, BIPopupMenuComponent, BISideBarComponent, BITreeComponent, BeforeAction, BiAccordionDirective, BiAccordionScopeDirective, BiAccordionToolbarDirective, BiAnchorPopupComponent, BiCardFilterComponent, BiCardNavComponent, BiCardSorterComponent, BiCardsComponent, BiDialog, BiDropDownComponent, BiFloatingDropDownComponent, BiFloatingLookupComponent, BiLogoGalleryComponent, BiMasterGridComposedComponent, BiMasterGridDetailsChildrenComponent, BiMasterGridDetailsComponent, BiMatTabAutoResetDirective, BiMobileColumnCustomizerComponent, BiMultiSelectComponent, BiNavComponent, BiPhotoUploaderComponent, ColViewService, CreateDialog, ErrorDetailsService, ErrorMessageComponent, ExpandCollapseRegistryService, GetValuePipe, LoadingMode, LoggerService, NegativeValueTransformPipe, NotificationService, NumericKeyboardDirective, SideBarContentComponent, SideBarErrorDetailsComponent, UiProfileService, UserUIProfile, biControlListComponent, biControlListin2ColComponent, filterValuesPipe };
export type { DialogData, INotificationOption };
