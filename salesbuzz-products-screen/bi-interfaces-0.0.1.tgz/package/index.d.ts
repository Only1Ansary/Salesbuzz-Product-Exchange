import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter, Type } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';
export * from 'rxjs';
import { FormGroup, FormControl, ValidatorFn } from '@angular/forms';
import { CompositeFilterDescriptor, SortDescriptor, State, FilterDescriptor } from '@progress/kendo-data-query';

declare class BIInterfacesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BIInterfacesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BIInterfacesModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BIInterfacesModule>;
}

interface IDataService {
    edit(APIURL: string, data: any): Observable<any>;
    patch(APIURL: string, data: any): Observable<any>;
    add(APIURL: string, data: any): Observable<any>;
    delete(APIURL: string, id: string): Observable<any>;
    fetch(APIURL: string, filter: string): Observable<any>;
}

declare enum DataSourceType {
    OData = "OData",
    api = "api"
}

declare enum DataTypes {
    Boolean = "boolean",
    Text = "text",
    NUMERIC = "numeric",
    Date = "date",
    Image = "image",
    LogError = "LogError",
    ProgressBar = "progressbar"
}

declare enum ControlTypes {
    Text = "text",
    Number = "number",
    Generic = "Generic",
    Date = "date",
    DateTime = "datetime",
    Time = "time",
    CheckBox = "checkbox",
    Select = "select",
    MultiSelect = "multiSelect",
    Title = "title",
    Empty = "empty",
    Lookup = "lookup",
    TextArea = "textarea",
    Color = "color",
    LogText = "logText",
    LogImage = "LogImage",
    Password = "password",
    ProgressBar = "progressbar",
    Template = "template",
    Image = "Image",
    HyperLink = "HyperLink",
    UID = "UID"
}

interface IDataSource {
    Params: {
        Name: string;
        Operator: string;
        value: string;
        DataType: any;
    }[];
    Key: string;
    Key2: string;
    Key3: string;
    Key4: string;
    Key5: string;
    Key6: string;
    Columns: {
        Name: string;
        DataType: DataTypes;
        Length?: number;
        controlType?: ControlTypes;
        dropDownTemplate?: {
            value: string;
            text: string;
            HasStatuesIcon?: boolean;
            list: any[];
            SuggestedList?: any[];
            OnValueChange?: Function;
            OnselectionChange?: Function;
            OnOpen?: Function;
            OnFocus?: Function;
        };
    }[];
    Type: DataSourceType;
    IsClientSideFilter: boolean;
    LocalData: boolean;
    data: any[];
    HasPaging: boolean;
    state: {
        skip: number;
        take: number;
        sort: [];
    };
    edit(data: any, id: string): Observable<any>;
    patch(data: any, id: string): Observable<any>;
    add(data: any): Observable<any>;
    delete(id: string): Observable<any>;
    batch(CreatedItemArray: Array<any>, UpdatedItemArray: Array<any>, DeletedItemArray: Array<any>): Observable<any>;
    read(filter: string): void;
    get(APIURL: string): Observable<any>;
    formatAPIURLWithFilter(filter: string): string;
    formatFilter(filter: string): string;
    loading: boolean;
    APIURL: string;
    POSTAPIURL: string | undefined;
    PUTAPIURL: string | undefined;
    DELETEAPIURL: string | undefined;
    excludeDataFromReq: Array<string>;
    excludeTimeFromReq: Array<string>;
}

interface IGridBase {
    DataService: any;
    changeSet: any;
    Columns: Object;
    AllowSave: Subject<boolean>;
    AllowDelete: Subject<boolean>;
    AllowAdd: Subject<boolean>;
    CurrentSelectRow: FormGroup;
    DomID: string | undefined;
    BeforeActionSave: () => void;
    BeforeActionDelete: () => void;
    AfterActionSave: () => void;
    CheckPendingChange: () => boolean;
    read: () => void;
    EnableDisable_columns(colmnNames: string[], IsEditable: boolean): void;
    SetValue(ColumnName: string, Value: any, MarkAsDirty: boolean): void;
    GetRowValue(): any;
    GetValueOf(Name: string): any;
    ConvertBoolean2Number(): void;
    closeRow: () => void;
    Cancel: () => void;
    Save: () => void;
    DeleteRow: () => void;
    AddRow: () => void;
    ClearGrid: () => void;
    RefreshCurrentRow(AfterRefreshFunc: Function): void;
}

interface IGrid extends IGridBase {
    GridData: Observable<any>;
    formGroups: Array<FormGroup>;
    HasPaging: boolean | undefined;
    DefaultValue: any;
    HasSelectAll: boolean | undefined;
    RowCount: number;
    changeCheckAll: (event: any, Name: string) => void;
    GetCurrentSelectRow_ChangeSetStatus(): string;
    bindingData(event: any, name: string): void;
    handleDate(date: Date | any): Date | any;
    setFilter: (fieldName: string, value: string, dataType: DataTypes) => void;
    RefreshCurrentRow(AfterRefreshFunc: Function): void;
    ResetFilters(): void;
}

declare class ExtendedMap extends Map {
    constructor();
    find(fn: any): any;
    filter(fn: any): any[];
    map(fn: any): any[];
    reduce(fn: any, first: any): any;
}

interface ICards extends IGridBase {
    formGroups: ExtendedMap;
    HeaderTemplate: TemplateRef<any>;
    FooterTemplate: TemplateRef<any>;
    CardEditTemplate: TemplateRef<any>;
    CardTemplate: TemplateRef<any>;
    view: any[];
    data: any[];
    filters: string;
    sorter: string;
    LoadingMode: any;
    EnterEditMode: (dataItem: any) => void;
    SetInternalFilter(filter: string): void;
}

interface IChangeset {
    changesetArr: Array<{
        Grid: IGrid | ICards;
    }>;
}

interface ILookup {
    IsDisabled: boolean;
    Isvalid: boolean;
    Key: string | undefined;
    DomID: string | undefined;
    SelectedRow: any;
    lookupValue: any;
    Description: string | undefined;
    rtlDescription: string;
    GoToDefinitionURl: string;
    Title: string;
    DataSource: IDataSource;
    OnEnterGrid: EventEmitter<any>;
    BeforeLoad: EventEmitter<any>;
    AfterLoad: EventEmitter<any>;
    OnHover: EventEmitter<any>;
    OnClose: EventEmitter<any>;
    OnOpen: EventEmitter<any>;
    OnOpenSecondLkp: EventEmitter<any>;
    OnFocus: EventEmitter<any>;
    ReturnedValueEmitter: EventEmitter<any>;
    cellClickHandler: (args: any) => void;
    dblClickEvent: (event: any) => void;
    OnTextChange: (event: any) => Promise<void>;
    SetIsDisable: (boolean: boolean) => void;
    Cancel: () => void;
    Ok: () => void;
    OpenModal: () => void;
    CloseModal: () => void;
    FilterChange: (event: any) => void;
}

interface ITest {
    Name: string;
    Operator: string;
    value: string;
    DataType: DataTypes;
}

declare enum StatusAction {
    ADD = "add",
    UPDATE = "update"
}

interface ILogger {
    Type: number;
    Content: string;
    Show: () => void;
}

interface IDropDown {
    IsDisabled: boolean;
    SelectedRow: any;
    TextField: string;
    ValueField: string;
    BindingProperty: FormControl;
    OnValueChange: EventEmitter<any>;
    OnselectionChange: EventEmitter<any>;
    OnFocus: EventEmitter<any>;
    OnOpen: EventEmitter<any>;
}

declare enum TypeError {
    ERROR = 0,
    Message = 1
}

interface IErrorMessages {
    Title: string;
    Details: string;
    Link?: string;
    Parameter?: string;
    Id: number;
    Type: TypeError;
}

declare enum NavButton {
    add = "add",
    save = "save",
    delete = "delete",
    info = "info",
    attach = "attach",
    cancel = "cancel",
    print = "print",
    ColView = "ColView",
    workFlow = "workFlow",
    searchbar = "searchbar",
    historyData = "historyData",
    favorite = "favorite"
}

declare enum RecordSourceEnum {
    Salesbuzz = 0,
    Infinity_ERP = 1,
    MS_Dynamics_AX = 2,
    Oracle_EBS = 3,
    IBM_AS_400 = 4,
    MS_GP = 5,
    SAP = 6,
    ISCALA = 7,
    Mandoobi = 14,
    MandoobiTemp = 15,
    OracleFusion = 20,
    SAPB1 = 8,
    Infor = 9,
    BASIS = 10
}

declare enum ValueDataType {
    None = 0,
    Numeric = 1,
    Time = 2,
    Datetime = 3,
    Text = 4
}

declare enum AttributeType {
    Lookup = 0,
    Text = 1,
    Hierarchy = 2,
    Date = 3,
    CheckBox = 4
}

interface ICreateDialog {
    DialogReturnSubject: Subject<any>;
    ShowDialog(component: Type<any>, data: any, modalTitle: string): void;
    CloseDialog(): void;
}

interface IBiAnchorPopup {
    Width: string;
    Height: string;
    onToggle: () => void;
}

declare abstract class ControlBase {
}

declare abstract class IControls extends ControlBase {
    DomID: string | undefined;
    Name: string;
    DisplayName: string;
    controlType?: string;
    colNumber: number;
    rowNumber: number;
    colSpanNumber?: number;
    DataType?: any;
    IsEditable?: boolean;
    IsFilterable?: boolean;
    IsNumber2Boolean?: Boolean;
    DefaultValue?: string | number | null | Date | boolean;
    viewCellStyle?: string;
    IsVisible?: boolean;
    Width?: number;
    Style?: string;
    Mask?: string;
    HyperLink?: string;
    lookupTemplate?: {
        Key: string | undefined;
        ID: string | undefined;
        Description?: string;
        AfterLoad?: Function;
        BeforeLoad?: Function;
        OnClose?: Function;
        OnOpen?: Function;
        OnOpenSecondLkp?: Function;
        ReturnedValueEmitter?: Function;
        DataSource: any;
        hasSecondLkp?: boolean;
        route?: string;
        Title?: string;
        hasSelection?: boolean | undefined;
        validateCheckExistence?: boolean;
    };
    dropDownTemplate?: {
        value: string;
        text: string;
        list: any[];
        IsFilterable?: boolean;
        SuggestedList?: any[];
        OnValueChange?: Function | undefined;
        OnselectionChange?: Function;
        OnOpen?: Function;
        OnFocus?: Function;
    };
    ActionButton?: {
        Action: Function;
    };
    Validators?: ValidatorFn | null | Array<ValidatorFn>;
    TextAfterInput?: string;
    colorPickerSettings?: {
        required: boolean;
        clearButton?: boolean;
    };
    datePickerSettings?: {
        dateFormat: string;
    };
    TemplateRef?: TemplateRef<any>;
    Precision?: number;
    LogImageTemplate?: {
        filterList: any[];
    };
}

declare abstract class IColumns extends ControlBase {
    DomID: string | undefined;
    Validators?: ValidatorFn | null | Array<ValidatorFn>;
    Name: string;
    DisplayName: string;
    DataType: any;
    IsEditable: boolean;
    IsFilterable: boolean;
    IsNumber2Boolean?: Boolean;
    DefaultValue?: string | number | null | Date | boolean;
    controlType?: string;
    viewCellStyle?: string;
    ConditionalCellStyleFn?: Function;
    IsVisible: boolean;
    Width?: number;
    Route?: string;
    ModalTitle?: string;
    ClickableText?: string;
    LogImageTemplate?: {
        filterList: {
            image: string;
            showOnValue: number;
            text?: string;
        }[];
    };
    imgs?: {
        image: string;
        showOnValue: number;
        text?: string;
    }[];
    lookupTemplate?: {
        Key: string | undefined;
        ID: string | undefined;
        Description?: string;
        AfterLoad?: Function;
        BeforeLoad?: Function;
        OnClose?: Function;
        OnOpen?: Function;
        OnFocus?: Function;
        OnOpenSecondLkp?: Function;
        ReturnedValueEmitter?: Function;
        DataSource: any;
        hasSecondLkp?: boolean;
        validateCheckExistence?: boolean;
        route?: string;
        Title?: string;
        hasSelection?: boolean;
    };
    dropDownTemplate?: {
        value: string;
        text: string;
        HasStatuesIcon?: boolean;
        list: any[];
        SuggestedList?: any[];
        OnValueChange?: Function;
        OnselectionChange?: Function;
        OnOpen?: Function;
        OnFocus?: Function;
    };
    checkboxTemplate?: {
        HasSelectAll: boolean | undefined;
        HasSelectAllLabel?: boolean | undefined;
    };
    removeNegativeTransform?: boolean;
    Precision?: number;
    IsHiddenByUser?: boolean;
    cardViewVisibility?: number;
    Order?: number;
    DataBaseId?: number;
}

interface IField {
    FieldName: string;
    DataType: DataTypes;
    IsEditable?: boolean | undefined;
    IsFilterable?: boolean | undefined;
    DefaultValue?: string | number | null | Date | boolean | undefined;
    Width?: number;
    Validators?: ValidatorFn | null | Array<ValidatorFn>;
    IsPrimaryKey?: boolean;
    IsSubmitExcluded?: boolean | undefined;
    removeNegativeTransform?: boolean;
    ConditionalCellStyleFn?: Function;
}
interface IEntity {
    EntityName: string;
    Fields: IField[];
    ODATAAPIURL?: string;
    POSTAPIURL?: string | undefined;
    PUTAPIURL?: string | undefined;
    DELETEAPIURL?: string | undefined;
    FieldsToExecludeFromInsertUpdate?: IField[];
}
declare class BIEntity implements IEntity {
    EntityName: string;
    Fields: IField[];
    ODATAAPIURL?: string;
    POSTAPIURL?: string | undefined;
    PUTAPIURL?: string | undefined;
    DELETEAPIURL?: string | undefined;
    FieldsToExecludeFromInsertUpdate?: IField[];
    constructor();
}
declare abstract class IBIControl extends ControlBase {
    Group?: string;
    DomID?: string | undefined;
    FieldName: string;
    DisplayName?: string;
    controlType: ControlTypes;
    IsEditable?: boolean;
    IsFilterable?: boolean;
    IsNumber2Boolean?: Boolean;
    DefaultValue?: string | number | null | Date | boolean;
    viewCellStyle?: string;
    IsVisible?: boolean;
    Width?: number;
    Mask?: string;
    lookupTemplate?: {
        Key: string | undefined;
        ID: string | undefined;
        Description?: string;
        AfterLoad?: Function;
        BeforeLoad?: Function;
        OnClose?: Function;
        OnOpen?: Function;
        OnFocus?: Function;
        OnOpenSecondLkp?: Function;
        ReturnedValueEmitter?: Function;
        DataSource: any;
        hasSecondLkp?: boolean;
        route?: string;
        Title?: string;
        hasSelection?: boolean;
    };
    dropDownTemplate?: {
        value: string;
        text: string;
        list: any[];
        SuggestedList?: any[];
        OnValueChange?: Function;
        OnselectionChange?: Function;
        OnOpen?: Function;
        OnFocus?: Function;
    };
    Validators?: ValidatorFn | null | Array<ValidatorFn>;
    colNumber: number;
    rowNumber: number;
    ShowinOverviewGrid?: boolean;
    ClickableText?: string;
    ModalTitle?: string;
    checkboxTemplate?: {
        HasSelectAll: boolean | undefined;
        HasSelectAllLabel?: boolean | undefined;
    };
    imgs?: {
        image: string;
        showOnValue: number;
        text?: string;
    }[];
    LogImageTemplate?: {
        filterList: {
            image: string;
            showOnValue: number;
            text?: string;
        }[];
    };
    TextAfterInput?: string;
    TemplateRef?: TemplateRef<any>;
    Precision?: number;
}
declare class BIEntity_Controls {
    protected DBTable: BIEntity;
    protected ControlList: IControls[];
    protected groupedControlList: {
        group: string;
        Control: IControls;
    }[];
    protected BIControlList: IBIControl[];
    protected OverviewAndFromGroupColumns: IColumns[];
    protected charWidthinPixels: number;
    defaultColWidth: number;
    getDatasourceColumns(): {
        Name: string;
        DataType: DataTypes;
    }[];
    setFieldControlProperties(inputContol: IBIControl): void;
    getAllControlList(): IControls[];
    getControlListByGroup(Group: string): IControls[];
    getOverviewAndFromGroupColumns(): IColumns[];
}

interface IGridSteps {
    GridData: any[];
    Columns: IColumns[];
    ColumnsKey: string;
    RowDataChangeSubject$: Subject<any>;
    OrignalOrder: string;
    IsDirty: boolean;
    changeCheckBox: (currentRow: any, colName: string) => void;
    PopPendingChanges: () => void;
}

interface IUIProfileService {
    IsUserUIProfileFilled: boolean;
    UserUIProfileFilled$: Observable<void>;
    isCurrentScreenFavoriteDelegate?: () => boolean;
    saveColumnLayout$: Observable<{
        LayoutColumns: number | null;
    }>;
    saveColumnsConfig$: Observable<{
        GridDomId: string;
        Columns: IColumns[];
    }>;
    favoriteScreenChanged$: Observable<any>;
    emitSaveColumnLayout(layoutColumns: number | null): void;
    emitSaveColumnsConfig(gridDomId: string, columns: IColumns[]): void;
}

interface ILayoutSaver {
    SaveLayoutForScreenClicked(): void;
}

type NavButtonProperties = {
    disable: boolean;
    visibility: boolean;
};
interface INavBtn extends Partial<Record<NavButton, NavButtonProperties>> {
}

interface INav {
    DomID: string | undefined;
    CanInsert: boolean;
    CanUpdate: boolean;
    CanDelete: boolean;
    navButtons: INavBtn;
    deleteConfirmMsg: boolean;
    CanPrint: boolean | undefined;
    HistoryData: {
        Table: string;
        KeyID: string;
    };
    AddRow(): void;
    DeleteRow(): void;
    Cancel(): void;
    Save(): void;
    Info(): void;
    Close(): void;
}

interface ITree {
    DomID: string | undefined;
    data: any[];
    textField: string;
    filterable: boolean;
    size: 'small' | 'medium' | 'large';
    selectedKeys: any[];
    treeViewElem: any;
    childrenField: string;
    onSelectionChange(event: any): void;
    onFocus(): void;
    onBlur(): void;
    onExpand(event: any): void;
    onCollapse(event: any): void;
    onFilterChange(event: string): void;
    onFilterStateChange(event: any): void;
}

interface IGallery {
    DomID: string | undefined;
    data: any[];
    mode: 'single' | 'multiple';
    keyId: string;
    uploadingProgress: {
        load: boolean;
        progress: any;
    };
    selectedImage: any;
    selectedIndex: number;
    selectedImageData: any;
    previewSrc: string;
    src: string;
    saveURL: string;
    isBanner: boolean;
    deleteImage(image: any): void;
    prev(): void;
    next(): void;
    selectImage(image: string, index: number): void;
}

declare class BIObservable extends Observable<any> {
}

interface IExportSettings {
    HasExport: boolean;
    ExportFileName: string;
    ExportToExcel(): void;
}

interface IPopup {
    DisplayCancel: boolean | undefined;
    Title: string | undefined;
    openDialog: () => void;
    CloseDialog: () => void;
    OK: () => void;
    OnClose: () => void;
    OnOpen: () => void;
    OnOk: () => void;
    AllowSave: Subject<boolean>;
    BeforeActionSave: () => void;
}

interface ISearchItem {
    path: string;
    text: string;
    pathInBreadCrumb: string[];
}

interface IChildGrid extends IGrid {
}

interface IMenuItem {
    text?: string;
    icon?: string;
    path?: string;
    speratorTitle?: string;
    selected?: boolean;
    separator?: boolean;
    disabeld?: boolean;
    children?: any;
}

interface IPhotoUploader {
    uploadPhotoClicked: EventEmitter<any>;
    selectPhotoClicked: EventEmitter<any>;
    completeUpload: EventEmitter<any>;
    clearPhotoClicked: EventEmitter<any>;
    LabelName: string;
    BindingProperty: FormControl;
    MainFormGroup: FormGroup;
    ClearBtnDisabled: boolean;
    UploadBtnDisabled: boolean;
    AutoUpload: boolean;
    SaveUrl: any;
}

interface ICardNav {
    isSorterOpen: boolean;
    filter: CompositeFilterDescriptor;
    sorter: SortDescriptor;
    FilterSubscribtion: Subscription;
    SorterSubscribtion: Subscription;
    OnOpenFilter(): void;
    OnFilter(event: any): void;
    OnOpenSorter(): void;
    OnSort(event: any): void;
}

interface ICardFilter {
    state: State;
    data: {
        value: CompositeFilterDescriptor;
        Columns: IColumns[];
        Dialog: any;
    };
    onFilterChange(value: CompositeFilterDescriptor): void;
    editorValueChange(value: any, currentItem: FilterDescriptor, filterValue: CompositeFilterDescriptor): void;
}

interface IBinLocation {
    BINLocation: number;
    L1Description: string;
    IsSystem: number;
    VisibleInPda: number;
}

interface ICardSorter {
    state: State;
    SortingOrder: "asc" | "desc" | undefined;
    data: {
        value: SortDescriptor[];
        Columns: IColumns[];
        Dialog: any;
    };
    editorValueChange(ColumnName: any): void;
}

interface IDialog {
    data: any;
    outputValue: any;
    OnOk: () => void;
    OnCancel: (onclose: boolean) => void;
}

interface IColumnConfig {
    Id?: number;
    ScreenPath: string;
    Name: string;
    Order: number;
    IsVisible: boolean;
    cardViewVisibility?: number;
    GridId: string;
    UserName: string;
}

interface IScreen {
    Id?: string;
    PageName: string;
    PageUrl: string;
}

interface IRecentScreen extends IScreen {
    VisitTime: number;
}

interface ICustomScreenLayout {
    Id?: number;
    ScreenPath: string;
    MediaQuery: string;
    LayoutColumns: number;
    UserName: string;
}

declare abstract class NavInfo {
    abstract getBUDesc(BUID: string): any;
}

export { AttributeType, BIEntity, BIEntity_Controls, BIInterfacesModule, BIObservable, ControlTypes, DataTypes, ExtendedMap, IBIControl, IColumns, IControls, NavButton, NavInfo, RecordSourceEnum, StatusAction, TypeError, ValueDataType };
export type { IBiAnchorPopup, IBinLocation, ICardFilter, ICardNav, ICardSorter, ICards, IChangeset, IChildGrid, IColumnConfig, ICreateDialog, ICustomScreenLayout, IDataService, IDataSource, IDialog, IDropDown, IEntity, IErrorMessages, IExportSettings, IField, IGallery, IGrid, IGridBase, IGridSteps, ILayoutSaver, ILogger, ILookup, IMenuItem, INav, INavBtn, IPhotoUploader, IPopup, IRecentScreen, IScreen, ISearchItem, ITest, ITree, IUIProfileService };
