import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { Observable } from 'rxjs';
export * from 'rxjs';

//import { ExtendedMap } from './ExtendedMap';
class BIInterfacesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.24", ngImport: i0, type: BIInterfacesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.24", ngImport: i0, type: BIInterfacesModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.24", ngImport: i0, type: BIInterfacesModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.24", ngImport: i0, type: BIInterfacesModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: [],
                    providers: [
                    // ExtendedMap
                    ]
                }]
        }] });

var DataTypes;
(function (DataTypes) {
    DataTypes["Boolean"] = "boolean";
    DataTypes["Text"] = "text";
    DataTypes["NUMERIC"] = "numeric";
    DataTypes["Date"] = "date";
    DataTypes["Image"] = "image";
    DataTypes["LogError"] = "LogError";
    DataTypes["ProgressBar"] = "progressbar";
})(DataTypes || (DataTypes = {}));

var StatusAction;
(function (StatusAction) {
    StatusAction["ADD"] = "add";
    StatusAction["UPDATE"] = "update";
})(StatusAction || (StatusAction = {}));

var ControlTypes;
(function (ControlTypes) {
    ControlTypes["Text"] = "text";
    ControlTypes["Number"] = "number";
    ControlTypes["Generic"] = "Generic";
    ControlTypes["Date"] = "date";
    ControlTypes["DateTime"] = "datetime";
    ControlTypes["Time"] = "time";
    ControlTypes["CheckBox"] = "checkbox";
    ControlTypes["Select"] = "select";
    ControlTypes["MultiSelect"] = "multiSelect";
    ControlTypes["Title"] = "title";
    ControlTypes["Empty"] = "empty";
    ControlTypes["Lookup"] = "lookup";
    ControlTypes["TextArea"] = "textarea";
    ControlTypes["Color"] = "color";
    ControlTypes["LogText"] = "logText";
    ControlTypes["LogImage"] = "LogImage";
    ControlTypes["Password"] = "password";
    ControlTypes["ProgressBar"] = "progressbar";
    ControlTypes["Template"] = "template";
    ControlTypes["Image"] = "Image";
    ControlTypes["HyperLink"] = "HyperLink";
    ControlTypes["UID"] = "UID";
})(ControlTypes || (ControlTypes = {}));

var NavButton;
(function (NavButton) {
    NavButton["add"] = "add";
    NavButton["save"] = "save";
    NavButton["delete"] = "delete";
    NavButton["info"] = "info";
    NavButton["attach"] = "attach";
    NavButton["cancel"] = "cancel";
    NavButton["print"] = "print";
    NavButton["ColView"] = "ColView";
    NavButton["workFlow"] = "workFlow";
    NavButton["searchbar"] = "searchbar";
    NavButton["historyData"] = "historyData";
    NavButton["favorite"] = "favorite";
})(NavButton || (NavButton = {}));

var RecordSourceEnum;
(function (RecordSourceEnum) {
    RecordSourceEnum[RecordSourceEnum["Salesbuzz"] = 0] = "Salesbuzz";
    RecordSourceEnum[RecordSourceEnum["Infinity_ERP"] = 1] = "Infinity_ERP";
    RecordSourceEnum[RecordSourceEnum["MS_Dynamics_AX"] = 2] = "MS_Dynamics_AX";
    RecordSourceEnum[RecordSourceEnum["Oracle_EBS"] = 3] = "Oracle_EBS";
    RecordSourceEnum[RecordSourceEnum["IBM_AS_400"] = 4] = "IBM_AS_400";
    RecordSourceEnum[RecordSourceEnum["MS_GP"] = 5] = "MS_GP";
    RecordSourceEnum[RecordSourceEnum["SAP"] = 6] = "SAP";
    RecordSourceEnum[RecordSourceEnum["ISCALA"] = 7] = "ISCALA";
    // RoadNet = 8, we take * for SAP B1
    RecordSourceEnum[RecordSourceEnum["Mandoobi"] = 14] = "Mandoobi";
    RecordSourceEnum[RecordSourceEnum["MandoobiTemp"] = 15] = "MandoobiTemp";
    RecordSourceEnum[RecordSourceEnum["OracleFusion"] = 20] = "OracleFusion";
    RecordSourceEnum[RecordSourceEnum["SAPB1"] = 8] = "SAPB1";
    RecordSourceEnum[RecordSourceEnum["Infor"] = 9] = "Infor";
    RecordSourceEnum[RecordSourceEnum["BASIS"] = 10] = "BASIS";
})(RecordSourceEnum || (RecordSourceEnum = {}));

var TypeError;
(function (TypeError) {
    TypeError[TypeError["ERROR"] = 0] = "ERROR";
    TypeError[TypeError["Message"] = 1] = "Message";
})(TypeError || (TypeError = {}));

var ValueDataType;
(function (ValueDataType) {
    ValueDataType[ValueDataType["None"] = 0] = "None";
    ValueDataType[ValueDataType["Numeric"] = 1] = "Numeric";
    ValueDataType[ValueDataType["Time"] = 2] = "Time";
    ValueDataType[ValueDataType["Datetime"] = 3] = "Datetime";
    ValueDataType[ValueDataType["Text"] = 4] = "Text";
})(ValueDataType || (ValueDataType = {}));

var AttributeType;
(function (AttributeType) {
    AttributeType[AttributeType["Lookup"] = 0] = "Lookup";
    AttributeType[AttributeType["Text"] = 1] = "Text";
    AttributeType[AttributeType["Hierarchy"] = 2] = "Hierarchy";
    AttributeType[AttributeType["Date"] = 3] = "Date";
    AttributeType[AttributeType["CheckBox"] = 4] = "CheckBox";
})(AttributeType || (AttributeType = {}));

class ControlBase {
}

class IControls extends ControlBase {
}

class IColumns extends ControlBase {
    constructor() {
        super(...arguments);
        this.IsEditable = false;
        this.IsFilterable = false;
        this.IsVisible = false;
    }
}

;
;
class BIEntity {
    constructor() {
        this.EntityName = "";
        this.Fields = [];
    }
}
function CopyCommonProperties(Source, Destination) {
    const commonKeys = Object.keys(Source).filter((key) => Destination.hasOwnProperty(key));
    commonKeys.forEach((key) => {
        Destination[key] = Source[key];
    });
}
class IBIControl extends ControlBase {
}
class BIEntity_Controls {
    constructor() {
        this.ControlList = [];
        this.groupedControlList = [];
        this.BIControlList = [];
        this.OverviewAndFromGroupColumns = [];
        this.charWidthinPixels = 8;
        this.defaultColWidth = 10;
    }
    getDatasourceColumns() {
        /*return this.ControlList.map( field =>
          {
              return {Name: field.Name , DataType: field.DataType};
    
          }
          )
        */
        return this.DBTable.Fields.map(field => {
            return { Name: field.FieldName, DataType: field.DataType };
        });
    }
    setFieldControlProperties(inputContol) {
        let calculatedWidth = 20;
        let CalculatedWidthPct = 100;
        const maxWidthPct = 100;
        const numberFieldMaxWidth = 20;
        const displayMaxWidth = 35;
        const maxColWidth = 50;
        let control = { Name: "", controlType: ControlTypes.Text, colNumber: 0, rowNumber: 0, DomID: "", DisplayName: "", IsVisible: true };
        let Column = {
            Name: "", DisplayName: "", DataType: DataTypes.Text,
            controlType: ControlTypes.Text, DefaultValue: 0,
            DomID: "", IsEditable: false, IsFilterable: false, IsVisible: false,
            Validators: null, viewCellStyle: ""
        };
        if (inputContol.controlType == ControlTypes.CheckBox &&
            this.DBTable.Fields.find(x => x.FieldName == inputContol.FieldName && x.DataType == DataTypes.NUMERIC)) {
            Column.IsNumber2Boolean = inputContol.IsNumber2Boolean = true;
        }
        //  CopyCommonProperties(inputContol,control);
        // CopyCommonProperties(inputContol,Column);
        if (inputContol.controlType === ControlTypes.Title || inputContol.controlType === ControlTypes.Empty) {
            control.Name = inputContol.FieldName;
            control.DisplayName = inputContol.DisplayName ?? inputContol.FieldName;
            control.DomID = inputContol.DomID ?? "BICNTRL_" + inputContol.FieldName;
            control.DataType = DataTypes.Text;
            control.IsEditable = false;
            control.IsFilterable = false;
            control.colNumber = inputContol.colNumber;
            control.rowNumber = inputContol.rowNumber;
            control.controlType = inputContol.controlType;
        }
        else {
            let FieldDetails;
            FieldDetails = this.DBTable.Fields.find(field => {
                return inputContol.FieldName.toLowerCase() === field.FieldName.toLowerCase();
            });
            if (FieldDetails && FieldDetails !== null && FieldDetails !== undefined) {
                control.Name = FieldDetails.FieldName;
                control.DisplayName = inputContol.DisplayName ?? FieldDetails.FieldName;
                control.DomID = inputContol.DomID ?? "BICNTRL_" + FieldDetails.FieldName;
                control.DataType = FieldDetails.DataType;
                control.IsEditable = inputContol.IsEditable ?? FieldDetails.IsEditable;
                control.IsFilterable = inputContol.IsFilterable ?? FieldDetails.IsFilterable;
                control.Mask = inputContol.Mask;
                // control.Width = inputContol.Width ?? FieldDetails.Width ?? numberFieldMaxWidth;
                control.colNumber = inputContol.colNumber;
                control.rowNumber = inputContol.rowNumber;
                control.controlType = inputContol.controlType;
                control.dropDownTemplate = inputContol.dropDownTemplate;
                control.lookupTemplate = inputContol.lookupTemplate;
                control.viewCellStyle = inputContol.viewCellStyle;
                control.Validators = inputContol.Validators ?? FieldDetails.Validators;
                control.DefaultValue = inputContol.DefaultValue ?? FieldDetails.DefaultValue ?? null;
                control.IsVisible = inputContol.IsVisible ?? true;
                control.TextAfterInput = inputContol.TextAfterInput;
                control.IsNumber2Boolean = inputContol.IsNumber2Boolean;
                control.TemplateRef = inputContol.TemplateRef;
                control.Precision = inputContol.Precision;
                // if (control.Width) {
                //   if (control.Width == 0)
                //     calculatedWidth = displayMaxWidth;
                //   else
                //     calculatedWidth = control.Width;
                //   if (calculatedWidth <= 25)
                //     calculatedWidth = 25;
                //   else
                //     calculatedWidth = displayMaxWidth;
                //   CalculatedWidthPct = maxWidthPct * (calculatedWidth / displayMaxWidth);
                // }
                // else {
                //   CalculatedWidthPct = maxWidthPct;
                // }
                // control.Style = 'width:' + CalculatedWidthPct.toFixed(0) + '% !important';
                Column.Name = control.Name;
                Column.DisplayName = control.DisplayName;
                Column.DomID = "F_" + control.DomID;
                Column.DataType = control.DataType;
                Column.IsEditable = control.IsEditable ?? false;
                Column.IsFilterable = control.IsFilterable ?? false;
                Column.Width = Math.min(((control.Width === null || control.Width === undefined) ? this.defaultColWidth : control.Width), maxColWidth) * this.charWidthinPixels;
                Column.controlType = (control.controlType == "checkbox" ? "boolean" : control.controlType == "number" ? "numeric" : control.controlType);
                Column.dropDownTemplate = control.dropDownTemplate;
                Column.lookupTemplate = control.lookupTemplate;
                Column.viewCellStyle = control.viewCellStyle ?? '';
                Column.Validators = control.Validators ?? null;
                Column.IsVisible = inputContol.ShowinOverviewGrid ?? false;
                Column.DefaultValue = control.DefaultValue ?? null;
                Column.ClickableText = inputContol.ClickableText;
                Column.ModalTitle = inputContol.ModalTitle;
                Column.checkboxTemplate = inputContol.checkboxTemplate;
                Column.imgs = inputContol.imgs;
                Column.removeNegativeTransform = FieldDetails.removeNegativeTransform;
                Column.ConditionalCellStyleFn = FieldDetails.ConditionalCellStyleFn;
                Column.Precision = inputContol.Precision;
                Column.LogImageTemplate = inputContol.LogImageTemplate;
                this.OverviewAndFromGroupColumns.push(Column);
            }
            else {
                //throw exception
                console.log("BIControls.AddControl --> Invalid field:" + inputContol.FieldName);
            }
        }
        if (inputContol.rowNumber !== 0) {
            if (!this.ControlList.find(x => x.Name == control.Name) == undefined)
                this.ControlList.push(control);
            this.groupedControlList.push({ group: inputContol.Group ?? '', Control: control });
        }
        this.BIControlList.push(inputContol);
    }
    getAllControlList() {
        return this.ControlList;
    }
    getControlListByGroup(Group) {
        return this.groupedControlList.filter(Rec => {
            if (Group.toLowerCase() === Rec.group.toLowerCase())
                return true;
            else
                return false;
        }).map(Rec => { return Rec.Control; });
    }
    getOverviewAndFromGroupColumns() {
        return this.OverviewAndFromGroupColumns;
    }
}

class BIObservable extends Observable {
}

class ExtendedMap extends Map {
    constructor() {
        super();
    }
    find(fn) {
        for (const [k, v] of this.entries()) {
            if (fn(v))
                return v;
        }
        return undefined;
    }
    filter(fn) {
        const res = [];
        for (const [k, v] of this.entries()) {
            if (fn(v))
                res.push(v);
        }
        return res;
    }
    map(fn) {
        const res = [];
        for (const [k, v] of this.entries()) {
            res.push(fn(v, k));
        }
        return res;
    }
    reduce(fn, first) {
        let res = first;
        for (const [k, v] of this.entries()) {
            res = fn(res, [k, v]);
        }
        return res;
    }
}

class NavInfo {
}

/*
 * Public API Surface of bi-interfaces
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AttributeType, BIEntity, BIEntity_Controls, BIInterfacesModule, BIObservable, ControlTypes, DataTypes, ExtendedMap, IBIControl, IColumns, IControls, NavButton, NavInfo, RecordSourceEnum, StatusAction, TypeError, ValueDataType };
//# sourceMappingURL=bi-interfaces.mjs.map
